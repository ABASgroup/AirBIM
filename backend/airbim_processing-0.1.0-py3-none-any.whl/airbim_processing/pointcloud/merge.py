from pathlib import Path
from typing import Iterable

import laspy


POINTS_PER_CHUNK = 1_000_000
POINT_FORMAT_STRATEGY_TARGET = "target"
POINT_FORMAT_STRATEGY_LARGEST = "largest"


def _resolve_existing_paths(paths_to_files: Iterable[str | Path]) -> list[Path]:
    paths = [Path(path).expanduser() for path in paths_to_files]
    if not paths:
        raise ValueError("paths_to_files не должен быть пустым.")

    missing_paths = [str(path) for path in paths if not path.is_file()]
    if missing_paths:
        raise FileNotFoundError(f"LAS/LAZ файлы не найдены: {missing_paths}")

    return [path.resolve() for path in paths]


def _choose_output_header(
    input_paths: list[Path],
    point_format_strategy: str,
) -> laspy.LasHeader:
    if point_format_strategy not in {
        POINT_FORMAT_STRATEGY_TARGET,
        POINT_FORMAT_STRATEGY_LARGEST,
    }:
        raise ValueError(
            "point_format_strategy должен быть 'target' или 'largest'."
        )

    if point_format_strategy == POINT_FORMAT_STRATEGY_TARGET:
        with laspy.open(input_paths[0]) as reader:
            return reader.header.copy()

    largest_header = None
    largest_dimension_count = -1
    for path in input_paths:
        with laspy.open(path) as reader:
            dimension_count = len(list(reader.header.point_format.dimension_names))
            if dimension_count > largest_dimension_count:
                largest_header = reader.header.copy()
                largest_dimension_count = dimension_count

    return largest_header


def _copy_common_dimensions(source_points, target_points) -> None:
    target_points.x = source_points.x
    target_points.y = source_points.y
    target_points.z = source_points.z

    source_dimensions = set(source_points.point_format.dimension_names)
    target_dimensions = set(target_points.point_format.dimension_names)
    common_dimensions = source_dimensions & target_dimensions
    common_dimensions -= {"X", "Y", "Z"}

    for dimension in common_dimensions:
        target_points[dimension] = source_points[dimension]


def _convert_chunk_to_target_format(chunk, target_header: laspy.LasHeader):
    if chunk.point_format == target_header.point_format:
        return chunk

    target_points = laspy.ScaleAwarePointRecord.zeros(
        len(chunk),
        header=target_header,
    )
    _copy_common_dimensions(chunk, target_points)
    return target_points


def _rescale_chunk_if_needed(chunk, target_header: laspy.LasHeader) -> None:
    if (
        hasattr(chunk, "change_scaling")
        and (
            (chunk.scales != target_header.scales).any()
            or (chunk.offsets != target_header.offsets).any()
        )
    ):
        chunk.change_scaling(
            scales=target_header.scales,
            offsets=target_header.offsets,
        )


def _write_file_chunks(
    path: Path,
    writer,
    target_header: laspy.LasHeader,
) -> None:
    with laspy.open(path) as reader:
        for chunk in reader.chunk_iterator(POINTS_PER_CHUNK):
            chunk = _convert_chunk_to_target_format(chunk, target_header)
            _rescale_chunk_if_needed(chunk, target_header)

            if hasattr(writer, "append_points"):
                writer.append_points(chunk)
            else:
                writer.write_points(chunk)


def merge_laz_files(
    paths_to_files: Iterable[str | Path],
    result_path: str | Path,
    point_format_strategy: str = POINT_FORMAT_STRATEGY_TARGET,
) -> None:
    """
    Объединяет LAS/LAZ файлы из paths_to_files в один LAZ файл result_path.

    Если result_path совпадает с одним из paths_to_files, итоговый файл
    открывается на дозапись, а остальные файлы дописываются в него.
    Файлы читаются чанками, чтобы не держать все точки в памяти.

    point_format_strategy:
    - "target": использовать point_format существующего result_path или
      первого входного файла для нового result_path;
    - "largest": для нового result_path взять point_format у входного файла
      с самым большим количеством dimensions.
    """
    input_paths = _resolve_existing_paths(paths_to_files)
    result_path = Path(result_path).expanduser()
    result_resolved = result_path.resolve()
    append_to_existing = result_resolved in input_paths

    if append_to_existing:
        paths_to_append = [path for path in input_paths if path != result_resolved]
        if not paths_to_append:
            return

        with laspy.open(result_resolved, mode="a") as appender:
            target_header = appender.header
            for path in paths_to_append:
                _write_file_chunks(path, appender, target_header)
        return

    result_path.parent.mkdir(parents=True, exist_ok=True)

    output_header = _choose_output_header(input_paths, point_format_strategy)

    with laspy.open(
        result_path,
        mode="w",
        header=output_header,
        do_compress=True,
    ) as writer:
        target_header = writer.header
        for path in input_paths:
            _write_file_chunks(path, writer, target_header)
