"""Raw pointcloud processing pipeline for real scanner LAS/LAZ 
files, with conservative defaults."""
from __future__ import annotations

import os
import shutil
import tempfile
from dataclasses import dataclass
from math import isfinite
from pathlib import Path

import pdal


@dataclass(frozen=True)
class RawScanPipelineConfig:
    """
    Conservative defaults for real scanner LAS/LAZ files.
    """

    deduplicate_cell_m: float | None = 0.001
    poisson_sample_radius_m: float | None = None
    statistical_outlier: bool = True
    outlier_mean_k: int = 16
    outlier_multiplier: float = 2.5
    radius_outlier_radius_m: float | None = None
    radius_outlier_min_k: int = 4
    z_mad_k: float | None = None
    crop_min_xyz: tuple[float | None, float | None, float | None] | None = None
    crop_max_xyz: tuple[float | None, float | None, float | None] | None = None
    noise_class: int = 1
    compress_output: bool | None = None


def _build_crop_expression(
    min_xyz: tuple[float | None, float | None, float | None] | None,
    max_xyz: tuple[float | None, float | None, float | None] | None,
) -> str | None:
    if min_xyz is None and max_xyz is None:
        return None
    if min_xyz is not None and len(min_xyz) != 3:
        raise ValueError("crop_min_xyz must contain exactly 3 values: X, Y, Z")
    if max_xyz is not None and len(max_xyz) != 3:
        raise ValueError("crop_max_xyz must contain exactly 3 values: X, Y, Z")

    dimensions = ("X", "Y", "Z")
    expressions: list[str] = []

    for index, dimension in enumerate(dimensions):
        min_value = None if min_xyz is None else min_xyz[index]
        max_value = None if max_xyz is None else max_xyz[index]

        if min_value is not None:
            min_value = float(min_value)
            if not isfinite(min_value):
                raise ValueError(f"crop_min_xyz[{index}] must be finite")
            expressions.append(f"{dimension} >= {min_value}")

        if max_value is not None:
            max_value = float(max_value)
            if not isfinite(max_value):
                raise ValueError(f"crop_max_xyz[{index}] must be finite")
            expressions.append(f"{dimension} <= {max_value}")

        if min_value is not None and max_value is not None and min_value > max_value:
            raise ValueError(f"crop_min_xyz[{index}] must be <= crop_max_xyz[{index}]")

    return " && ".join(expressions) if expressions else None


def build_raw_scan_pipeline(
    input_path: str | Path,
    output_path: str | Path,
    config: RawScanPipelineConfig | None = None,
) -> pdal.Pipeline:
    """
    Build a PDAL pipeline for raw real scans.

    The default pipeline removes exact/near duplicates with a streamable voxel
    filter, then marks statistical outliers as LAS noise class 1 and drops them.
    Expensive low-point and clustering filters are intentionally not enabled by
    default because they are dataset-dependent and can require a lot of RAM.
    """
    config = RawScanPipelineConfig() if config is None else config
    input_path = Path(input_path)
    output_path = Path(output_path)

    pipeline = pdal.Reader.las(filename=str(input_path))

    crop_expression = _build_crop_expression(config.crop_min_xyz, config.crop_max_xyz)
    if crop_expression is not None:
        pipeline |= pdal.Filter.expression(expression=crop_expression)

    if config.deduplicate_cell_m is not None:
        pipeline |= pdal.Filter.voxeldownsize(cell=config.deduplicate_cell_m, mode="first")

    if config.poisson_sample_radius_m is not None:
        pipeline |= pdal.Filter.sample(radius=config.poisson_sample_radius_m)

    if config.z_mad_k is not None:
        if config.z_mad_k <= 0:
            raise ValueError("z_mad_k must be positive")
        pipeline |= pdal.Filter.mad(dimension="Z", k=config.z_mad_k)

    expressions_to_keep: list[str] = []

    if config.statistical_outlier:
        if config.outlier_mean_k <= 0:
            raise ValueError("outlier_mean_k must be positive")
        if config.outlier_multiplier <= 0:
            raise ValueError("outlier_multiplier must be positive")
        pipeline |= pdal.Filter.outlier(
            method="statistical",
            mean_k=config.outlier_mean_k,
            multiplier=config.outlier_multiplier,
            **{"class": config.noise_class},
        )
        expressions_to_keep.append(f"Classification != {config.noise_class}")

    if config.radius_outlier_radius_m is not None:
        if config.radius_outlier_min_k <= 0:
            raise ValueError("radius_outlier_min_k must be positive")
        pipeline |= pdal.Filter.outlier(
            method="radius",
            radius=config.radius_outlier_radius_m,
            min_k=config.radius_outlier_min_k,
            **{"class": config.noise_class},
        )
        noise_expression = f"Classification != {config.noise_class}"
        if noise_expression not in expressions_to_keep:
            expressions_to_keep.append(noise_expression)

    if expressions_to_keep:
        pipeline |= pdal.Filter.expression(expression=" && ".join(expressions_to_keep))

    compress_output = config.compress_output
    if compress_output is None:
        compress_output = output_path.suffix.lower() == ".laz"

    pipeline |= pdal.Writer.las(
        filename=str(output_path),
        forward="all",
        compression=compress_output,
    )
    return pipeline


def clean_raw_scan(
    input_path: str | Path,
    output_path: str | Path | None = None,
    config: RawScanPipelineConfig | None = None,
    verbose: bool = False,
) -> None:
    """
    Clean a raw real scanner LAS/LAZ file.

    If output_path is None, the input file is overwritten after a successful run.
    """
    input_path = Path(input_path)
    same_file_flag = output_path is None

    if same_file_flag:
        with tempfile.NamedTemporaryFile(suffix=input_path.suffix, delete=False) as tmp:
            output_path = Path(tmp.name)
    else:
        assert output_path is not None
        output_path = Path(output_path)

    try:
        pipeline = build_raw_scan_pipeline(input_path, output_path, config)

        if verbose:
            if pipeline.streamable:
                print("Raw scan pipeline supports streaming")
            else:
                print("Raw scan pipeline is not fully streamable; PDAL will keep point views in RAM")
            print("Running raw scan processing...")

        pipeline.execute()

        if same_file_flag:
            shutil.move(output_path, input_path)

        if verbose:
            print(f"Raw scan saved to {input_path if same_file_flag else output_path}")
    finally:
        if same_file_flag and output_path is not None and os.path.exists(output_path):
            os.remove(output_path)
