"""
Common utilities for point cloud processing, including LAZ loading and KDTree construction.
"""

import logging
from pathlib import Path

import laspy
import numpy as np
from scipy.spatial import cKDTree

# Optional GPU support
try:
    import cupy as cp
    from cupyx.scipy.spatial import KDTree as GPUKDTree

    GPU_AVAILABLE = cp.cuda.runtime.getDeviceCount() > 0
except Exception:
    cp = None
    GPUKDTree = None
    GPU_AVAILABLE = False

logger = logging.getLogger(__name__)


def load_xyz_from_laz(path: str | Path, chunk_size: int = 1_000_000) -> np.ndarray:
    """
    Load all (X, Y, Z) points from a LAZ file into memory.

    Parameters
    ----------
    path : str | Path
        Path to the LAZ file.
    chunk_size : int, optional
        Number of points to read per chunk, by default 1_000_000.

    Returns
    -------
    np.ndarray
        Array of shape (N, 3) containing the points as float64.

    Raises
    ------
    FileNotFoundError
        If the file does not exist.

    Examples
    --------
    >>> xyz = load_xyz_from_laz("scan.laz")
    """
    path = Path(path)
    parts = []
    with laspy.open(path) as reader:
        for pts in reader.chunk_iterator(chunk_size):
            xyz = np.column_stack((pts.x, pts.y, pts.z))
            parts.append(xyz.astype(np.float64, copy=False))
    if not parts:
        return np.empty((0, 3), dtype=np.float64)
    return np.concatenate(parts, axis=0)


def build_kdtree(xyz: np.ndarray, use_gpu: bool = False) -> tuple:
    """
    Build a KDTree (CPU or GPU) for the provided points.

    Parameters
    ----------
    xyz : np.ndarray
        Input points of shape (N, 3).
    use_gpu : bool, optional
        Whether to attempt building the tree on GPU, by default False.

    Returns
    -------
    tuple
        A tuple (tree, on_gpu, gpu_points) where ``tree`` is the built KDTree,
        ``on_gpu`` is a boolean indicating if GPU is actually used,
        and ``gpu_points`` is the cupy array if on GPU (otherwise None).
    """

    if use_gpu and GPU_AVAILABLE and cp and GPUKDTree:
        try:
            xyz_gpu = cp.asarray(xyz, dtype=cp.float32)
            tree = GPUKDTree(xyz_gpu)
            logger.info("Built GPU KDTree (cupyx).")
            return tree, True, xyz_gpu
        except Exception as e:
            logger.warning("GPU KDTree error: %s. Falling back to CPU.", e)

    tree = cKDTree(xyz)
    logger.info("Built CPU cKDTree (scipy).")
    return tree, False, None


def query_kdtree(tree, query_pts: np.ndarray, on_gpu: bool, k: int = 1, p: float = 2.0):
    """
    Query nearest neighbors from the constructed KDTree.

    Parameters
    ----------
    tree : KDTree (scipy or cupyx)
        The tree to query.
    query_pts : np.ndarray
        The points to query.
    on_gpu : bool
        Whether the tree is on GPU.
    k : int, optional
        Number of neighbors, by default 1.
    p : float, optional
        Minkowski p-norm, by default 2.0.

    Returns
    -------
    tuple
        Distances and indices.
    """
    if on_gpu and cp:
        q_gpu = cp.asarray(query_pts, dtype=cp.float32)
        dists_gpu, indices_gpu = tree.query(q_gpu, k=k, p=p)
        return cp.asnumpy(dists_gpu).astype(np.float32), cp.asnumpy(indices_gpu).astype(
            np.int64
        )
    else:
        return tree.query(query_pts, k=k, p=p, workers=-1)
