"""
Functions for merging multiple LAS/LAZ files into a single LAZ file.
"""

from pathlib import Path
from typing import Iterable

import laspy

POINTS_PER_CHUNK = 1_000_000
POINT_FORMAT_STRATEGY_TARGET = "target"
POINT_FORMAT_STRATEGY_LARGEST = "largest"


def _resolve_existing_paths(paths_to_files: Iterable[str | Path]) -> list[Path]:
    """
    Resolve and validate the input LAS/LAZ file paths.

    Parameters
    ----------
    paths_to_files : Iterable[str | Path]
        Input file paths to validate.

    Returns
    -------
    list[Path]
        Resolved absolute paths for all existing input files.

    Raises
    ------
    ValueError
        If ``paths_to_files`` is empty.
    FileNotFoundError
        If one or more input files do not exist.
    """
    paths = [Path(path).expanduser() for path in paths_to_files]
    if not paths:
        raise ValueError("paths_to_files не должен быть пустым.")

    missing_paths = [str(path) for path in paths if not path.is_file()]
    if missing_paths:
        raise FileNotFoundError(f"LAS/LAZ файлы не найдены: {missing_paths}")

    return [path.resolve() for path in paths]


def _choose_output_header(
    input_paths: list[Path],
    point_format_strategy: str,
) -> laspy.LasHeader:
    """
    Choose the output LAS header for the merged file.

    Parameters
    ----------
    input_paths : list[Path]
        Validated input file paths.
    point_format_strategy : str
        Strategy for selecting the output point format.

    Returns
    -------
    laspy.LasHeader
        Header used for the output file.

    Raises
    ------
    ValueError
        If ``point_format_strategy`` is not supported.
    """
    if point_format_strategy not in {
        POINT_FORMAT_STRATEGY_TARGET,
        POINT_FORMAT_STRATEGY_LARGEST,
    }:
        raise ValueError("point_format_strategy должен быть 'target' или 'largest'.")

    if point_format_strategy == POINT_FORMAT_STRATEGY_TARGET:
        with laspy.open(input_paths[0]) as reader:
            return reader.header.copy()

    largest_header = None
    largest_dimension_count = -1
    for path in input_paths:
        with laspy.open(path) as reader:
            dimension_count = len(list(reader.header.point_format.dimension_names))
            if dimension_count > largest_dimension_count:
                largest_header = reader.header.copy()
                largest_dimension_count = dimension_count

    return largest_header


def _copy_common_dimensions(source_points, target_points) -> None:
    """
    Copy shared point dimensions from one record into another.

    Parameters
    ----------
    source_points : Any
        Source LAS/LAZ point record.
    target_points : Any
        Destination LAS/LAZ point record.

    Returns
    -------
    None
    """
    target_points.x = source_points.x
    target_points.y = source_points.y
    target_points.z = source_points.z

    source_dimensions = set(source_points.point_format.dimension_names)
    target_dimensions = set(target_points.point_format.dimension_names)
    common_dimensions = source_dimensions & target_dimensions
    common_dimensions -= {"X", "Y", "Z"}

    for dimension in common_dimensions:
        target_points[dimension] = source_points[dimension]


def _convert_chunk_to_target_format(chunk, target_header: laspy.LasHeader):
    """
    Convert a chunk to the target point format when needed.

    Parameters
    ----------
    chunk : Any
        Input point chunk.
    target_header : laspy.LasHeader
        Header describing the desired output format.

    Returns
    -------
    Any
        Original chunk if the point format already matches, otherwise a new
        point record in the target format.
    """
    if chunk.point_format == target_header.point_format:
        return chunk

    target_points = laspy.ScaleAwarePointRecord.zeros(
        len(chunk),
        header=target_header,
    )
    _copy_common_dimensions(chunk, target_points)
    return target_points


def _rescale_chunk_if_needed(chunk, target_header: laspy.LasHeader) -> None:
    """
    Rescale a chunk to match the target header scaling if required.

    Parameters
    ----------
    chunk : Any
        Input point chunk.
    target_header : laspy.LasHeader
        Header whose scales and offsets should be matched.

    Returns
    -------
    None
    """
    if hasattr(chunk, "change_scaling") and (
        (chunk.scales != target_header.scales).any()
        or (chunk.offsets != target_header.offsets).any()
    ):
        chunk.change_scaling(
            scales=target_header.scales,
            offsets=target_header.offsets,
        )


def _write_file_chunks(
    path: Path,
    writer,
    target_header: laspy.LasHeader,
) -> None:
    """
    Write all points from one file to the output writer in chunks.

    Parameters
    ----------
    path : Path
        Input LAS/LAZ file path.
    writer : Any
        Open LAS/LAZ writer or appender.
    target_header : laspy.LasHeader
        Output header describing the merged file.

    Returns
    -------
    None
    """
    with laspy.open(path) as reader:
        for chunk in reader.chunk_iterator(POINTS_PER_CHUNK):
            chunk = _convert_chunk_to_target_format(chunk, target_header)
            _rescale_chunk_if_needed(chunk, target_header)

            if hasattr(writer, "append_points"):
                writer.append_points(chunk)
            else:
                writer.write_points(chunk)


def merge_laz_files(
    paths_to_files: Iterable[str | Path],
    result_path: str | Path,
    point_format_strategy: str = POINT_FORMAT_STRATEGY_TARGET,
) -> None:
    """
    Merge multiple LAS/LAZ files into a single LAZ file.

    Parameters
    ----------
    paths_to_files : Iterable[str | Path]
        Input LAS/LAZ file paths to merge.
    result_path : str | Path
        Output LAZ path.
    point_format_strategy : str ("target" or "largest"), default="target"
        Strategy for selecting the output point format.

    Returns
    -------
    None

    Raises
    ------
    ValueError
        If the input list is empty or the point format strategy is invalid.
    FileNotFoundError
        If any input file is missing.

    Examples
    --------
    Merge two files into a new LAZ file:

    >>> merge_laz_files(["part1.laz", "part2.laz"], "merged.laz")

    Append more points into an existing output file:

    >>> merge_laz_files(["merged.laz", "part3.laz"], "merged.laz")
    """
    input_paths = _resolve_existing_paths(paths_to_files)
    result_path = Path(result_path).expanduser()
    result_resolved = result_path.resolve()
    append_to_existing = result_resolved in input_paths

    if append_to_existing:
        paths_to_append = [path for path in input_paths if path != result_resolved]
        if not paths_to_append:
            return

        with laspy.open(result_resolved, mode="a") as appender:
            target_header = appender.header
            for path in paths_to_append:
                _write_file_chunks(path, appender, target_header)
        return

    result_path.parent.mkdir(parents=True, exist_ok=True)

    output_header = _choose_output_header(input_paths, point_format_strategy)

    with laspy.open(
        result_path,
        mode="w",
        header=output_header,
        do_compress=True,
    ) as writer:
        target_header = writer.header
        for path in input_paths:
            _write_file_chunks(path, writer, target_header)
