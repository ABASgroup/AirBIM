"""
Synthetic pointcloud processing pipeline for IFC-derived LAS/LAZ files.
"""

from __future__ import annotations

from dataclasses import dataclass
import logging
from math import isfinite
import os
from pathlib import Path
import shutil
import tempfile

import pdal

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SyntheticPcPipelineConfig:
    """
    Conservative cleanup for LAZ/LAS files generated from IFC meshes.

    IFC-derived clouds are deterministic mesh samples, so this pipeline only
    crops by coordinates and removes overlapping duplicate points.
    """

    deduplicate_cell_m: float | None = 0.001
    cluster_tolerance_m: float | None = None
    cluster_min_points: int = 1
    remove_unclustered_points: bool = False
    crop_min_xyz: tuple[float | None, float | None, float | None] | None = None
    crop_max_xyz: tuple[float | None, float | None, float | None] | None = None
    compress_output: bool | None = None


def _build_crop_expression(
    min_xyz: tuple[float | None, float | None, float | None] | None,
    max_xyz: tuple[float | None, float | None, float | None] | None,
) -> str | None:
    """
    Build a PDAL crop expression from optional coordinate bounds.

    Parameters
    ----------
    min_xyz : tuple[float | None, float | None, float | None] | None
        Minimum X, Y, Z bounds.
    max_xyz : tuple[float | None, float | None, float | None] | None
        Maximum X, Y, Z bounds.

    Returns
    -------
    str | None
        PDAL expression string, or ``None`` if no bounds were provided.

    Raises
    ------
    ValueError
        If the bound tuples do not contain exactly three values or are invalid.
    """
    if min_xyz is None and max_xyz is None:
        return None
    if min_xyz is not None and len(min_xyz) != 3:
        raise ValueError("crop_min_xyz must contain exactly 3 values: X, Y, Z")
    if max_xyz is not None and len(max_xyz) != 3:
        raise ValueError("crop_max_xyz must contain exactly 3 values: X, Y, Z")

    dimensions = ("X", "Y", "Z")
    expressions: list[str] = []

    for index, dimension in enumerate(dimensions):
        min_value = None if min_xyz is None else min_xyz[index]
        max_value = None if max_xyz is None else max_xyz[index]

        if min_value is not None:
            min_value = float(min_value)
            if not isfinite(min_value):
                raise ValueError(f"crop_min_xyz[{index}] must be finite")
            expressions.append(f"{dimension} >= {min_value}")

        if max_value is not None:
            max_value = float(max_value)
            if not isfinite(max_value):
                raise ValueError(f"crop_max_xyz[{index}] must be finite")
            expressions.append(f"{dimension} <= {max_value}")

        if min_value is not None and max_value is not None and min_value > max_value:
            raise ValueError(f"crop_min_xyz[{index}] must be <= crop_max_xyz[{index}]")

    return " && ".join(expressions) if expressions else None


def build_synthetic_ifc_pipeline(
    input_path: str | Path,
    output_path: str | Path,
    config: SyntheticPcPipelineConfig | None = None,
) -> pdal.Pipeline:
    """
    Build a PDAL pipeline for IFC-derived synthetic point clouds.

    Parameters
    ----------
    input_path : str | Path
        Input LAS/LAZ file path.
    output_path : str | Path
        Output LAS/LAZ file path.
    config : SyntheticPcPipelineConfig | None, default=None
        Pipeline configuration.

    Returns
    -------
    pdal.Pipeline
        Configured PDAL pipeline.

    Raises
    ------
    ValueError
        If a configured numeric threshold is invalid.

    Examples
    --------
    Build a default synthetic cleaning pipeline:

    >>> pipeline = build_synthetic_ifc_pipeline("input.laz", "output.laz")

    Build a pipeline with cropping and clustering enabled:

    >>> config = SyntheticPcPipelineConfig(
    ...     crop_min_xyz=(0.0, 0.0, 0.0),
    ...     crop_max_xyz=(10.0, 10.0, 10.0),
    ...     cluster_tolerance_m=0.05,
    ... )
    >>> pipeline = build_synthetic_ifc_pipeline("input.laz", "output.laz", config)
    """
    config = SyntheticPcPipelineConfig() if config is None else config
    input_path = Path(input_path)
    output_path = Path(output_path)

    pipeline = pdal.Reader.las(filename=str(input_path))

    crop_expression = _build_crop_expression(config.crop_min_xyz, config.crop_max_xyz)
    if crop_expression is not None:
        pipeline |= pdal.Filter.expression(expression=crop_expression)

    if config.deduplicate_cell_m is not None:
        if config.deduplicate_cell_m <= 0:
            raise ValueError("deduplicate_cell_m must be positive")
        pipeline |= pdal.Filter.voxeldownsize(
            cell=config.deduplicate_cell_m, mode="first"
        )

    if config.remove_unclustered_points and config.cluster_tolerance_m is None:
        raise ValueError(
            "cluster_tolerance_m must be set when remove_unclustered_points is true"
        )

    if config.cluster_tolerance_m is not None:
        if config.cluster_tolerance_m <= 0:
            raise ValueError("cluster_tolerance_m must be positive")
        if config.cluster_min_points <= 0:
            raise ValueError("cluster_min_points must be positive")
        pipeline |= pdal.Filter.cluster(
            tolerance=config.cluster_tolerance_m,
            min_points=config.cluster_min_points,
        )

        if config.remove_unclustered_points:
            pipeline |= pdal.Filter.expression(expression="ClusterID != 0")

    compress_output = config.compress_output
    if compress_output is None:
        compress_output = output_path.suffix.lower() == ".laz"

    writer_options = {
        "filename": str(output_path),
        "forward": "all",
        "compression": compress_output,
    }
    if config.cluster_tolerance_m is not None and not config.remove_unclustered_points:
        writer_options["extra_dims"] = "ClusterID=int64"

    pipeline |= pdal.Writer.las(**writer_options)
    return pipeline


def clean_synthetic_ifc_laz(
    input_path: str | Path,
    output_path: str | Path | None = None,
    config: SyntheticPcPipelineConfig | None = None,
) -> None:
    """
    Clean an IFC-derived synthetic LAS/LAZ file.

    Parameters
    ----------
    input_path : str | Path
        Input LAS/LAZ file path.
    output_path : str | Path | None, default=None
        Output LAS/LAZ file path. If ``None``, the input file is overwritten.
    config : SyntheticPcPipelineConfig | None, default=None
        Pipeline configuration.
    verbose : bool, default=False
        Print progress messages.

    Returns
    -------
    None

    Examples
    --------
    Clean a file in place:

    >>> clean_synthetic_ifc_laz("input.laz")

    Write the cleaned result to a new file:

    >>> clean_synthetic_ifc_laz("input.laz", "output.laz", verbose=True)
    """

    input_path = Path(input_path)
    same_file_flag = output_path is None

    if same_file_flag:
        with tempfile.NamedTemporaryFile(suffix=input_path.suffix, delete=False) as tmp:
            output_path = Path(tmp.name)
    else:
        assert output_path is not None
        output_path = Path(output_path)

    try:
        pipeline = build_synthetic_ifc_pipeline(input_path, output_path, config)

        if pipeline.streamable:
            logger.info("Synthetic IFC pipeline supports streaming")
        else:
            logger.info(
                "Synthetic IFC pipeline is not fully streamable; PDAL will keep point views in RAM"
            )
        logger.info("Running synthetic IFC processing...")

        pipeline.execute()

        if same_file_flag:
            shutil.move(output_path, input_path)

        logger.info(
            "Synthetic IFC LAZ saved to %s",
            input_path if same_file_flag else output_path,
        )
    finally:
        if same_file_flag and output_path is not None and os.path.exists(output_path):
            os.remove(output_path)
