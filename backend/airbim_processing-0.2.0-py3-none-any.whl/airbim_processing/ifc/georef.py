"""
Functions for extracting coordinates from an IFC file and then creating a coordinate
transformation matrix.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
import re
from typing import Any

import ifcopenshell
import ifcopenshell.util.element as ifcelement
import ifcopenshell.util.geolocation as ifcgeo
import ifcopenshell.util.placement as ifcplacement
import ifcopenshell.util.unit as ifcunit
import numpy as np
from pyproj import CRS, Transformer
from pyproj.aoi import AreaOfInterest
from pyproj.database import query_crs_info, query_utm_crs_info
from pyproj.enums import PJType

# =========================
# Public result structures
# =========================


class GeoSource(IntEnum):
    NO_REAL_COORDS = 0
    IFC_MAPCONVERSION_EPSG = 1
    IFC_MAPCONVERSION_WKT = 2
    IFC_GEOGRAPHIC_DERIVED_PROJECTED = 3
    SITE_WGS84_DERIVED_PROJECTED = 4
    IFC_PARTIAL_UNRESOLVED_CRS = 5


@dataclass
class CrsRef:
    authority: str | None
    code: str | None
    label: str | None
    wkt: str | None


@dataclass
class SourceLog:
    code: int
    name: str
    approximate: bool
    messages: list[str] = field(default_factory=list)


@dataclass
class GeoTransformResult:
    crs: CrsRef | None
    matrix: np.ndarray | None  # 4x4, world/WCS -> output CRS units
    project_unit_m: float  # size of 1 project unit in metres
    crs_unit_m: float | None  # size of 1 horizontal CRS unit in metres
    source: SourceLog


# =========================
# Internal helper structs
# =========================


@dataclass
class OperationDiscovery:
    kind: str  # "projected" | "geographic" | "unknown"
    name: str | None
    wkt: str | None
    crs_raw: Any | None
    op_raw: Any | None
    via: str


# =========================
# Low-level safe helpers
# =========================


def _safe_by_type(model: ifcopenshell.file, ifc_class: str) -> list[Any]:
    """
    Safely returns IFC entities of the requested class from the model.

    This helper wraps ``model.by_type()`` and prevents the pipeline from failing when:
    - the requested IFC class does not exist in the current schema version;
    - the model is malformed or incomplete;
    - IfcOpenShell raises an exception while resolving the class.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model as ``ifcopenshell.file``.
    ifc_class : str
        IFC entity name, for example ``"IfcSite"`` or
                ``"IfcProjectedCRS"``.

    Returns
    -------
    list[Any]
        A list of matching IFC entities. Returns an empty list if the
                class is not available or any error occurs.
    """
    try:
        result = model.by_type(ifc_class)
        return list(result) if result else []
    except Exception:
        return []


def _first_or_none(seq: list[Any]) -> Any | None:
    """
    Returns the first element of a sequence or ``None`` if it is empty.

    Parameters
    ----------
    seq : list[Any]
        Input sequence.

    Returns
    -------
    Any | None
        The first element of ``seq`` if present, otherwise ``None``.
    """
    return seq[0] if seq else None


def _safe_attr(obj: Any, name: str, default: Any = None) -> Any:
    """
    Safely reads an attribute from an object.

    This helper is used because IFC entities may differ across schema versions,
    and some attributes may be missing, inaccessible, or raise exceptions on
    access.

    Parameters
    ----------
    obj : Any
        Object from which the attribute should be read.
    name : str
        Attribute name.
    default : Any
        Value to return if ``obj`` is ``None``, the attribute does not
                exist, or reading the attribute fails.

    Returns
    -------
    Any
        The attribute value or ``default``.
    """
    if obj is None:
        return default
    try:
        return getattr(obj, name)
    except Exception:
        return default


def _append(messages: list[str], text: str) -> None:
    """
    Appends a unique log message to the message list.

    Parameters
    ----------
    messages : list[str]
        Mutable list of log messages.
    text : str
        Message to append.

    Returns
    -------
    None
    """
    if text not in messages:
        messages.append(text)


# =========================
# CRS parsing helpers
# =========================

_AUTH_CODE_RE = re.compile(r"^\s*([A-Za-z][A-Za-z0-9_]*)\s*:\s*([0-9A-Za-z._-]+)\s*$")


def _parse_authority_code(text: str | None) -> tuple[str | None, str | None]:
    """
    Parses a CRS identifier of the form ``AUTHORITY:CODE``. Without validation.

    Examples of supported inputs include:
    - ``"EPSG:3857"``
    - ``"EPSG:25832"``
    - ``"ESRI:102100"``

    Parameters
    ----------
    text : str | None
        Raw CRS label string.

    Returns
    -------
    tuple[str | None, str | None]
        A tuple ``(authority, code)`` if parsing succeeds.
            Returns ``(None, None)`` if the string does not
                match the expected pattern.
    """
    if not text:
        return None, None
    m = _AUTH_CODE_RE.match(text)
    if not m:
        return None, None
    return m.group(1).upper(), m.group(2)


def _extract_wkt_from_crs_entity(crs_entity: Any) -> str | None:
    """
    Extracts Well-Known Text (WKT) from an IFC CRS entity if available.

    The function first tries direct access through the CRS entity and then
    falls back to scanning ``IfcWellKnownText`` instances linked to the CRS.
    This is implemented defensively because inverse attributes and toolchain
    behavior may differ between IFC versions and exports.

    Parameters
    ----------
    crs_entity : Any
        IFC CRS entity, typically ``IfcProjectedCRS`` or
                ``IfcGeographicCRS``.

    Returns
    -------
    str | None
        The WKT string if it can be found and read successfully;
            otherwise ``None``.
    """
    if crs_entity is None:
        return None

    # Most direct / likely path
    try:
        rel = getattr(crs_entity, "WellKnownText", None)
        if rel:
            if isinstance(rel, (list, tuple)):
                rel = rel[0] if rel else None
            if rel is not None:
                text = _safe_attr(rel, "WellKnownText")
                if isinstance(text, str) and text.strip():
                    return text.strip()
    except Exception:
        pass

    try:
        model = crs_entity.wrapped_data.file
    except Exception:
        model = None

    # Brute-force fallback: scan IfcWellKnownText instances and match inverse link
    if model is not None:
        for wkt_entity in _safe_by_type(model, "IfcWellKnownText"):
            try:
                linked_crs = _safe_attr(wkt_entity, "CoordinateReferenceSystem")
                if linked_crs and linked_crs.id() == crs_entity.id():
                    text = _safe_attr(wkt_entity, "WellKnownText")
                    if isinstance(text, str) and text.strip():
                        return text.strip()
            except Exception:
                continue

    return None


def _build_pyproj_crs(
    authority: str | None,
    code: str | None,
    name: str | None,
    wkt: str | None,
) -> CRS | None:
    """
    Builds a ``pyproj.CRS`` instance from IFC CRS information.

    Resolution order:
    1. ``authority:code`` parsed from the CRS name;
    2. raw CRS name passed to ``CRS.from_user_input()``;
    3. WKT text passed to ``CRS.from_user_input()``.

    Parameters
    ----------
    authority : str | None
        CRS authority, for example ``"EPSG"``.
    code : str | None
        CRS code, for example ``"25832"``.
    name : str | None
        Raw CRS name from IFC.
    wkt : str | None
        WKT representation of the CRS, if available.

    Returns
    -------
    CRS | None
        Parsed ``pyproj.CRS`` instance, or ``None`` if none of the
            input forms can be resolved.
    """
    # 1) AUTH:CODE
    if authority and code:
        try:
            return CRS.from_user_input(f"{authority}:{code}")
        except Exception:
            pass
    # 2) raw Name (sometimes valid user input)
    if name:
        try:
            return CRS.from_user_input(name)
        except Exception:
            pass
    # 3) WKT
    if wkt:
        try:
            return CRS.from_user_input(wkt)
        except Exception:
            pass
    return None


def _coerce_crs(value: CRS | str | int | None) -> CRS | None:
    """
    Converts a flexible CRS input into a ``pyproj.CRS`` instance.

    Supported input forms:
    - existing ``pyproj.CRS``;
    - integer EPSG code;
    - string accepted by ``CRS.from_user_input()``.

    Parameters
    ----------
    value : CRS | str | int | None
        CRS-like input.

    Returns
    -------
    CRS | None
        Parsed CRS object, or ``None`` if the value cannot be
            converted.
    """
    if value is None:
        return None
    if isinstance(value, CRS):
        return value
    if isinstance(value, int):
        try:
            return CRS.from_epsg(value)
        except Exception:
            return None
    if isinstance(value, str):
        try:
            return CRS.from_user_input(value)
        except Exception:
            return None
    return None


def _get_crs_horizontal_unit_m(pyproj_crs: CRS) -> float | None:
    """
    Returns the horizontal CRS unit size in meters.

    The function inspects axis metadata exposed by ``pyproj.CRS.axis_info`` and
    returns the first positive numeric ``unit_conversion_factor`` it finds.

    Parameters
    ----------
    pyproj_crs : CRS
        Parsed CRS object.

    Returns
    -------
    float | None
        Size of one horizontal CRS unit in meters, or ``None`` if
            the unit cannot be determined.
    """
    try:
        for axis in pyproj_crs.axis_info:
            factor = getattr(axis, "unit_conversion_factor", None)
            if isinstance(factor, (int, float)) and factor > 0:
                return float(factor)
    except Exception:
        pass
    return None


def _check_vertical_unit_consistency(
    pyproj_crs: CRS,
    horizontal_unit_m: float,
    messages: list[str],
) -> None:
    """
    Logs a warning if the vertical CRS axis unit differs from the horizontal unit.

    This function is used because the pipeline applies uniform XYZ scaling when
    constructing a 4x4 matrix. If the vertical unit differs from the horizontal
    unit, that assumption becomes approximate.

    Parameters
    ----------
    pyproj_crs : CRS
        Parsed CRS object.
    horizontal_unit_m : float
        Horizontal unit size in meters.
    messages : list[str]
        Mutable log message list.

    Returns
    -------
    None
    """
    try:
        if len(pyproj_crs.axis_info) >= 3:
            factor = getattr(pyproj_crs.axis_info[2], "unit_conversion_factor", None)
            if (
                isinstance(factor, (int, float))
                and factor > 0
                and abs(float(factor) - horizontal_unit_m) > 1e-12
            ):
                _append(
                    messages,
                    "Vertical axis unit differs from horizontal axis unit; matrix uses horizontal CRS unit for uniform XYZ scaling.",
                )
    except Exception:
        pass


def _to_crs_ref(
    pyproj_crs: CRS | None, name: str | None, wkt: str | None
) -> CrsRef | None:
    """
    Builds a normalized ``CrsRef`` object from parsed CRS information.

    The function prefers CRS authority/code derived from ``pyproj``. If that is
    not available, it falls back to the raw IFC name and WKT.

    Parameters
    ----------
    pyproj_crs : CRS | None
        Parsed CRS object, if available.
    name : str | None
        Raw CRS name from IFC.
    wkt : str | None
        CRS WKT, if available.

    Returns
    -------
    CrsRef | None
        Normalized CRS reference object, or ``None`` if no CRS
            information is available.
    """
    authority: str | None = None
    code: str | None = None
    label: str | None = None

    if pyproj_crs is None:
        if not name and not wkt:
            return None
        authority, code = _parse_authority_code(name)
        label = (
            f"{authority}:{code}" if authority and code else ("WKT" if wkt else name)
        )
        return CrsRef(authority=authority, code=code, label=label, wkt=wkt)

    try:
        auth = pyproj_crs.to_authority()
        if auth:
            authority, code = auth[0], auth[1]
            label = f"{authority}:{code}"
    except Exception:
        pass

    if label is None:
        authority, code = _parse_authority_code(name)
        label = (
            f"{authority}:{code}"
            if authority and code
            else ("WKT" if wkt else pyproj_crs.to_string())
        )

    out_wkt: str | None
    try:
        out_wkt = pyproj_crs.to_wkt()
    except Exception:
        out_wkt = wkt

    return CrsRef(authority=authority, code=code, label=label, wkt=out_wkt)


# =========================
# IFC discovery helpers
# =========================


def _find_pset_dict(
    model: ifcopenshell.file,
    pset_names: tuple[str, ...],
    entity_types: tuple[str, ...],
) -> tuple[dict[str, Any] | None, str | None]:
    """
    Searches property sets on given IFC entity types and returns the first match.

    This helper is intended for legacy or non-authoritative metadata paths such
    as IFC2X3 property sets.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.
    pset_names : tuple[str, ...]
        Candidate property set names to search for.
    entity_types : tuple[str, ...]
        IFC entity types on which the property sets should be
                searched.

    Returns
    -------
    tuple[dict[str, Any] | None, str | None]
        A tuple containing the matched
            property set dictionary and a textual description of where it was found.
            Returns ``(None, None)`` if nothing is found.
    """
    for entity_type in entity_types:
        for entity in _safe_by_type(model, entity_type):
            try:
                psets = ifcelement.get_psets(entity)
            except Exception:
                continue
            if not isinstance(psets, dict):
                continue
            for pset_name in pset_names:
                pset = psets.get(pset_name)
                if isinstance(pset, dict):
                    return pset, f"{entity_type}.{pset_name}"
    return None, None


def _find_coordinate_operation_bundle_from_context(
    model: ifcopenshell.file,
) -> OperationDiscovery | None:
    """
    Finds the authoritative coordinate operation and target CRS via IFC contexts.

    The function inspects ``IfcProject.RepresentationContexts`` and their
    ``HasCoordinateOperation`` relations, then extracts the operation and its
    ``TargetCRS``.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.

    Returns
    -------
    OperationDiscovery | None
        Structured discovery result containing the
            coordinate operation, target CRS metadata, and discovery path; otherwise
            ``None`` if nothing authoritative is found.
    """
    project = _first_or_none(_safe_by_type(model, "IfcProject"))
    if project is None:
        return None

    contexts = _safe_attr(project, "RepresentationContexts", []) or []
    for context in contexts:
        ops = _safe_attr(context, "HasCoordinateOperation", []) or []
        for op in ops:
            target = _safe_attr(op, "TargetCRS")
            if target is None:
                continue

            name = _safe_attr(target, "Name")
            wkt = _extract_wkt_from_crs_entity(target)

            try:
                if target.is_a("IfcProjectedCRS"):
                    return OperationDiscovery(
                        "projected",
                        name,
                        wkt,
                        target,
                        op,
                        "RepresentationContexts.HasCoordinateOperation.TargetCRS",
                    )
                if target.is_a("IfcGeographicCRS"):
                    return OperationDiscovery(
                        "geographic",
                        name,
                        wkt,
                        target,
                        op,
                        "RepresentationContexts.HasCoordinateOperation.TargetCRS",
                    )
            except Exception:
                pass

            return OperationDiscovery(
                "unknown",
                name,
                wkt,
                target,
                op,
                "RepresentationContexts.HasCoordinateOperation.TargetCRS",
            )
    return None


def _find_ifc2x3_projected_bundle_from_psets(
    model: ifcopenshell.file,
) -> OperationDiscovery | None:
    """
    Finds projected CRS metadata from IFC2X3-style property sets. Weaker than
    ``_find_coordinate_operation_bundle_from_context``.

    The function searches for projected CRS information in legacy property sets
    such as ``ePSet_ProjectedCRS``.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.

    Returns
    -------
    OperationDiscovery | None
        Discovery result containing projected CRS
            metadata if found; otherwise ``None``.
    """
    pset, via = _find_pset_dict(
        model,
        pset_names=("ePSet_ProjectedCRS", "EPset_ProjectedCRS", "ePset_ProjectedCRS"),
        entity_types=("IfcProject", "IfcSite"),
    )
    if not pset:
        return None

    name = pset.get("Name") or pset.get("name")
    wkt = pset.get("WellKnownText") or pset.get("WKT")
    if name or wkt:
        return OperationDiscovery(
            "projected", name, wkt, pset, None, via or "ProjectedCRS pset"
        )
    return None


def _discover_operation_bundle(model: ifcopenshell.file) -> OperationDiscovery | None:
    """
    Discovers the most relevant coordinate operation / CRS bundle available.

    Resolution order:
    1. authoritative IFC4+ context-based coordinate operation;
    2. IFC2X3 projected CRS property sets;
    3. direct scan for CRS entities as a last resort.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.

    Returns
    -------
    OperationDiscovery | None
        The best available discovery result, or
            ``None`` if no CRS-related metadata can be found.
    """
    found = _find_coordinate_operation_bundle_from_context(model)
    if found is not None:
        return found

    found = _find_ifc2x3_projected_bundle_from_psets(model)
    if found is not None:
        return found

    projected = _first_or_none(_safe_by_type(model, "IfcProjectedCRS"))
    if projected is not None:
        return OperationDiscovery(
            "projected",
            _safe_attr(projected, "Name"),
            _extract_wkt_from_crs_entity(projected),
            projected,
            None,
            "Direct IfcProjectedCRS scan",
        )

    geographic = _first_or_none(_safe_by_type(model, "IfcGeographicCRS"))
    if geographic is not None:
        rigid = _first_or_none(_safe_by_type(model, "IfcRigidOperation"))
        return OperationDiscovery(
            "geographic",
            _safe_attr(geographic, "Name"),
            _extract_wkt_from_crs_entity(geographic),
            geographic,
            rigid,
            "Direct IfcGeographicCRS scan",
        )

    return None


# =========================
# Matrix helpers
# =========================


def _make_uniform_affine(
    anchor_model_xyz: np.ndarray,
    anchor_target_xyz: np.ndarray,
    scale: float,
) -> np.ndarray:
    """
    Builds a uniform-scale affine matrix from a model anchor to a target anchor.

    The resulting matrix satisfies:

        target_xyz = scale * model_xyz + translation

    where the translation is chosen so that ``anchor_model_xyz`` maps exactly to
    ``anchor_target_xyz``.

    Parameters
    ----------
    anchor_model_xyz : np.ndarray
        Anchor point in model/project coordinates as a 3-vector.
    anchor_target_xyz : np.ndarray
        Corresponding anchor point in target CRS coordinates as
                a 3-vector.
    scale : float
        Uniform scale factor from model units to target CRS units.

    Returns
    -------
    np.ndarray
        A 4x4 affine transformation matrix.
    """
    if anchor_model_xyz.shape != (3,) or anchor_target_xyz.shape != (3,):
        raise ValueError("Expected 3D anchors.")
    M = np.eye(4, dtype=float)
    M[0, 0] = scale
    M[1, 1] = scale
    M[2, 2] = scale
    M[:3, 3] = anchor_target_xyz - scale * anchor_model_xyz
    return M


def _matrix_translation(matrix: np.ndarray) -> np.ndarray:
    """
    Extracts the translation component from a 4x4 affine matrix.

    Parameters
    ----------
    matrix : np.ndarray
        Input affine transformation matrix.

    Returns
    -------
    np.ndarray
        Translation vector of shape ``(3,)``.
    """
    arr = np.asarray(matrix, dtype=float)
    if arr.shape != (4, 4):
        raise ValueError("Expected 4x4 matrix")
    return arr[:3, 3].copy()


def _scale_matrix_project_units_to_crs_units(
    matrix_project_units: np.ndarray,
    project_unit_m: float,
    crs_unit_m: float,
) -> np.ndarray:
    """
    Converts a georeferencing matrix from project units to CRS units.

    The input matrix is expected to map model/project coordinates into georeferenced
    coordinates that are still numerically expressed in project units. The function
    left-multiplies the matrix by a uniform scale so that the output coordinates
    become expressed in CRS units.

    Parameters
    ----------
    matrix_project_units : np.ndarray
        Input 4x4 matrix whose output is expressed in
                project units.
    project_unit_m : float
        Size of one project unit in meters.
    crs_unit_m : float
        Size of one CRS unit in meters.

    Returns
    -------
    np.ndarray
        A 4x4 matrix whose output coordinates are expressed in CRS
            units.
    """
    arr = np.asarray(matrix_project_units, dtype=float)
    if arr.shape != (4, 4):
        raise ValueError("Expected a 4x4 matrix")
    if project_unit_m <= 0 or crs_unit_m <= 0:
        raise ValueError("Unit scales must be positive")

    k = project_unit_m / crs_unit_m
    S = np.eye(4, dtype=float)
    S[0, 0] = k
    S[1, 1] = k
    S[2, 2] = k
    return S @ arr


# =========================
# Angel helper
# =========================


def _compound_plane_angle_to_decimal_degrees(value: Any) -> float | None:
    """
    Converts an IFC angle representation into decimal degrees.

    The function supports:
    - plain numeric values;
    - iterable degree-minute-second values;
    - iterable degree-minute-second-microsecond values.

    Parameters
    ----------
    value : Any
        IFC angle representation, typically from ``RefLatitude`` or
                ``RefLongitude``.

    Returns
    -------
    float | None
        Angle in decimal degrees, or ``None`` if conversion fails.
    """
    if value is None:
        return None

    if isinstance(value, (int, float)):
        return float(value)

    try:
        parts = list(value)
    except Exception:
        parts = None

    if not parts:
        return None

    try:
        if len(parts) == 3:
            d, m, s = parts
            return ifcgeo.dms2dd(int(d), int(m), int(s), 0)
        if len(parts) >= 4:
            d, m, s, us = parts[:4]
            return ifcgeo.dms2dd(int(d), int(m), int(s), int(us))
    except Exception:
        pass

    try:
        parts = [float(x) for x in parts]
        sign = -1.0 if any(x < 0 for x in parts) else 1.0
        parts = [abs(x) for x in parts]
        dd = parts[0]
        if len(parts) > 1:
            dd += parts[1] / 60.0
        if len(parts) > 2:
            dd += parts[2] / 3600.0
        if len(parts) > 3:
            dd += parts[3] / 3_600_000_000.0
        return sign * dd
    except Exception:
        return None


# =========================
# Geografic CRS anchor extraction helpers
# =========================


def _extract_ifcsite_anchor_wgs84(site: Any) -> tuple[float, float, float] | None:
    """
    Extracts the WGS84 anchor point from an ``IfcSite``.

    The function reads ``RefLatitude``, ``RefLongitude``, and ``RefElevation``
    and returns them in a GIS-friendly coordinate order.

    Parameters
    ----------
    site : Any
        ``IfcSite`` entity.

    Returns
    -------
    tuple[float, float, float] | None
        Tuple ``(lon, lat, h)`` in WGS84 if
            latitude and longitude can be resolved; otherwise ``None``.
    """
    lat = _compound_plane_angle_to_decimal_degrees(_safe_attr(site, "RefLatitude"))
    lon = _compound_plane_angle_to_decimal_degrees(_safe_attr(site, "RefLongitude"))
    elev = _safe_attr(site, "RefElevation", 0.0)
    try:
        h = float(elev) if elev is not None else 0.0
    except Exception:
        h = 0.0

    if lat is None or lon is None:
        return None
    return float(lon), float(lat), h


def _get_wcs_matrix(model: ifcopenshell.file, messages: list[str]) -> np.ndarray:
    """
    Returns the World Coordinate System (WCS) matrix in project units.

    The function wraps ``ifcopenshell.util.geolocation.get_wcs()`` and falls back
    to the identity matrix if the WCS is missing, invalid, or cannot be parsed.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.
    messages : list[str]
        Mutable log message list.

    Returns
    -------
    np.ndarray
        A valid 4x4 WCS matrix in project units.
    """
    try:
        M = ifcgeo.get_wcs(model)
        if M is None:
            _append(messages, "get_wcs returned None; using identity.")
            return np.eye(4, dtype=float)
        arr = np.asarray(M, dtype=float)
        if arr.shape != (4, 4):
            _append(messages, "get_wcs returned a non-4x4 matrix; using identity.")
            return np.eye(4, dtype=float)
        return arr
    except Exception as exc:
        _append(messages, f"get_wcs failed: {exc}; using identity.")
        return np.eye(4, dtype=float)


def _get_project_origin_world(
    model: ifcopenshell.file, messages: list[str]
) -> np.ndarray:
    """
    Returns the project/world origin derived from the WCS matrix.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.
    messages : list[str]
        Mutable log message list.

    Returns
    -------
    np.ndarray
        Translation vector of shape ``(3,)`` representing the project
            origin in world/project coordinates.
    """
    M_wcs = _get_wcs_matrix(model, messages)
    return _matrix_translation(M_wcs)


def _get_site_origin_world(
    model: ifcopenshell.file, site: Any, messages: list[str]
) -> np.ndarray:
    """
    Returns the world/project coordinates of the ``IfcSite`` local origin.

    The function combines the model WCS with the site's local placement. If the
    site placement is missing or invalid, the WCS origin is used as a fallback.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.
    site : Any
        ``IfcSite`` entity whose placement origin should be resolved.
    messages : list[str]
        Mutable log message list.

    Returns
    -------
    np.ndarray
        Translation vector of shape ``(3,)`` representing the site
            origin in world/project coordinates.
    """
    M_wcs = _get_wcs_matrix(model, messages)

    placement = _safe_attr(site, "ObjectPlacement")
    if placement is None:
        _append(
            messages,
            "IfcSite.ObjectPlacement missing; using site origin at WCS origin.",
        )
        return _matrix_translation(M_wcs)

    try:
        M_site = np.asarray(ifcplacement.get_local_placement(placement), dtype=float)
        if M_site.shape != (4, 4):
            raise ValueError("Site placement matrix is not 4x4.")
    except Exception as exc:
        _append(
            messages,
            f"Failed to parse IfcSite.ObjectPlacement: {exc}; using WCS origin.",
        )
        return _matrix_translation(M_wcs)

    return _matrix_translation(M_wcs @ M_site)


def _extract_geographic_operation_anchor(
    op_raw: Any,
) -> tuple[float, float, float] | None:
    """
    Extracts a geographic anchor point from an ``IfcRigidOperation``.

    The function reads the operation's first coordinate, second coordinate, and
    height and interprets them as a point in the target geographic CRS.

    Parameters
    ----------
    op_raw : Any
        Raw coordinate operation entity, expected to be
                ``IfcRigidOperation``.

    Returns
    -------
    tuple[float, float, float] | None
        Tuple ``(x, y, z)`` from the geographic
            operation if available; otherwise ``None``.
    """
    if op_raw is None:
        return None

    try:
        if hasattr(op_raw, "is_a") and not op_raw.is_a("IfcRigidOperation"):
            return None
    except Exception:
        pass

    first = _safe_attr(op_raw, "FirstCoordinate")
    second = _safe_attr(op_raw, "SecondCoordinate")
    height = _safe_attr(op_raw, "Height", 0.0)

    try:
        x = float(first)
        y = float(second)
        z = float(height) if height is not None else 0.0
    except Exception:
        return None

    return x, y, z


# =========================
# Get projected CRS from geographic CRS helpers
# =========================


def _score_projected_candidate(candidate: CRS, source_geog_crs: CRS | None) -> float:
    """
    Scores a projected CRS candidate for automatic selection.

    The score favors candidates that:
    - are projected;
    - use meter units;
    - are not generic UTM if a more local projected CRS is available;
    - are compatible with the source geographic CRS or datum.

    Parameters
    ----------
    candidate : CRS
        Candidate projected CRS.
    source_geog_crs : CRS | None
        Source geographic CRS that should ideally match the
                candidate's geodetic basis.

    Returns
    -------
    float
        Ranking score. Higher is better.
    """
    score = 0.0

    try:
        if candidate.is_projected:
            score += 100.0
    except Exception:
        pass

    unit_m = _get_crs_horizontal_unit_m(candidate)
    if unit_m is not None and abs(unit_m - 1.0) < 1e-12:
        score += 20.0

    try:
        name_upper = candidate.name.upper()
        if "UTM" not in name_upper:
            score += 5.0
    except Exception:
        pass

    if source_geog_crs is not None:
        try:
            cand_geod = candidate.geodetic_crs
            src_geod = source_geog_crs.geodetic_crs or source_geog_crs
            if cand_geod and src_geod:
                cand_auth = cand_geod.to_authority()
                src_auth = src_geod.to_authority()
                if cand_auth and src_auth and cand_auth == src_auth:
                    score += 40.0
                elif getattr(cand_geod, "name", None) == getattr(
                    src_geod, "name", None
                ):
                    score += 30.0
                else:
                    cand_datum = getattr(candidate, "datum", None)
                    src_datum = getattr(source_geog_crs, "datum", None)
                    if cand_datum and src_datum and cand_datum.name == src_datum.name:
                        score += 20.0
        except Exception:
            pass

    return score


def _choose_projected_crs(
    lon_wgs84_deg: float,
    lat_wgs84_deg: float,
    source_geog_crs: CRS | None,
    preferred_projected_crs: CRS | str | int | None,
    messages: list[str],
) -> tuple[CRS | None, str]:
    """
    Chooses a projected CRS for geographic or site-based fallback branches.

    Resolution order:
    1. caller-provided preferred projected CRS;
    2. automatic AOI-based search in the CRS database;
    3. UTM fallback using the best available datum information.

    Parameters
    ----------
    lon_wgs84_deg : float
        Anchor longitude in WGS84 decimal degrees.
    lat_wgs84_deg : float
        Anchor latitude in WGS84 decimal degrees.
    source_geog_crs : CRS | None
        Source geographic CRS, if known.
    preferred_projected_crs : CRS | str | int | None
        Optional caller-provided target projected CRS.
    messages : list[str]
        Mutable log message list.

    Returns
    -------
    tuple[CRS | None, str]
        A tuple containing the chosen projected CRS and
            a string describing the selection mode. If no CRS can be chosen,
            returns ``(None, "no_projected_found")``.
    """
    preferred = _coerce_crs(preferred_projected_crs)
    if preferred is not None:
        try:
            if preferred.is_projected:
                _append(messages, "Using caller-provided preferred projected CRS.")
                return preferred, "explicit_preferred_projected"
        except Exception:
            pass
        _append(
            messages, "Caller-provided preferred CRS is not projected; ignoring it."
        )

    aoi = AreaOfInterest(
        west_lon_degree=lon_wgs84_deg,
        south_lat_degree=lat_wgs84_deg,
        east_lon_degree=lon_wgs84_deg,
        north_lat_degree=lat_wgs84_deg,
    )

    for contains in (True, False):
        try:
            infos = query_crs_info(
                auth_name="EPSG",
                pj_types=[PJType.PROJECTED_CRS],
                area_of_interest=aoi,
                contains=contains,
                allow_deprecated=False,
            )
        except Exception as exc:
            infos = []
            _append(messages, f"query_crs_info failed: {exc}")

        scored: list[tuple[float, CRS]] = []
        for info in infos:
            try:
                crs = CRS.from_user_input(f"{info.auth_name}:{info.code}")
            except Exception:
                continue
            try:
                if not crs.is_projected:
                    continue
            except Exception:
                continue
            scored.append((_score_projected_candidate(crs, source_geog_crs), crs))

        if scored:
            scored.sort(key=lambda item: item[0], reverse=True)
            chosen = scored[0][1]
            _append(
                messages,
                f"Automatically selected projected CRS by AOI search: {chosen.to_string()}.",
            )
            return chosen, "aoi_projected_match"

    datum_candidates: list[str] = []
    if source_geog_crs is not None:
        try:
            if source_geog_crs.datum and source_geog_crs.datum.name:
                datum_candidates.append(source_geog_crs.datum.name)
        except Exception:
            pass
        try:
            geod = source_geog_crs.geodetic_crs
            if geod and geod.datum and geod.datum.name:
                datum_candidates.append(geod.datum.name)
        except Exception:
            pass
    datum_candidates.append("WGS 84")

    seen = set()
    for datum_name in datum_candidates:
        if not datum_name or datum_name in seen:
            continue
        seen.add(datum_name)
        try:
            utm_infos = query_utm_crs_info(
                datum_name=datum_name, area_of_interest=aoi, contains=False
            )
        except Exception:
            utm_infos = []

        if utm_infos:
            try:
                crs = CRS.from_user_input(
                    f"{utm_infos[0].auth_name}:{utm_infos[0].code}"
                )
                _append(
                    messages, f"Using UTM fallback projected CRS: {crs.to_string()}."
                )
                return crs, "utm_fallback"
            except Exception:
                pass

    _append(messages, "Could not automatically choose a projected CRS.")
    return None, "no_projected_found"


# =========================
# Branch implementations
# =========================


def _resolve_projected_main_branch(
    model: ifcopenshell.file,
    discovery: OperationDiscovery,
    project_unit_m: float,
    messages: list[str],
) -> GeoTransformResult:
    """
    Resolves the authoritative projected CRS branch.

    This is the main branch used when the IFC contains authoritative projected
    georeferencing. The function:
    - parses the target projected CRS;
    - computes the base georeferencing matrix via
        ``auto_local2global(..., should_return_in_map_units=False)``;
    - converts the matrix output from project units to CRS units using
        ``pyproj`` unit metadata.

    This branch intentionally does not trust ``MapUnit`` as the source of the
    final numerical scaling. Instead, it takes the base matrix in project
    units and normalizes it to CRS units explicitly.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.
    discovery : OperationDiscovery
        Previously discovered operation/CRS bundle for a projected
                target CRS.
    project_unit_m : float
        Size of one project unit in meters.
    messages : list[str]
        Mutable log message list.

    Returns
    -------
    GeoTransformResult
        Final resolved georeferencing result for the
            authoritative projected branch.
    """
    name = discovery.name
    wkt = discovery.wkt

    authority, code = _parse_authority_code(name)
    pyproj_crs = _build_pyproj_crs(authority, code, name, wkt)
    if pyproj_crs is None:
        _append(
            messages, "Projected CRS found in IFC, but pyproj could not parse Name/WKT."
        )
        return GeoTransformResult(
            crs=_to_crs_ref(None, name, wkt),
            matrix=None,
            project_unit_m=project_unit_m,
            crs_unit_m=None,
            source=SourceLog(
                code=GeoSource.IFC_PARTIAL_UNRESOLVED_CRS,
                name="ifc_projected_crs_unresolved",
                approximate=False,
                messages=messages,
            ),
        )

    crs_unit_m = _get_crs_horizontal_unit_m(pyproj_crs)
    if crs_unit_m is None:
        _append(
            messages,
            "Could not determine CRS horizontal unit conversion factor from pyproj CRS.",
        )
        return GeoTransformResult(
            crs=_to_crs_ref(pyproj_crs, name, wkt),
            matrix=None,
            project_unit_m=project_unit_m,
            crs_unit_m=None,
            source=SourceLog(
                code=GeoSource.IFC_PARTIAL_UNRESOLVED_CRS,
                name="ifc_projected_crs_no_unit",
                approximate=False,
                messages=messages,
            ),
        )

    try:
        base_matrix = ifcgeo.auto_local2global(
            model,
            np.eye(4, dtype=float),
            should_return_in_map_units=False,
        )
    except Exception as exc:
        _append(
            messages,
            f"auto_local2global(..., should_return_in_map_units=False) failed: {exc}",
        )
        return GeoTransformResult(
            crs=_to_crs_ref(pyproj_crs, name, wkt),
            matrix=None,
            project_unit_m=project_unit_m,
            crs_unit_m=crs_unit_m,
            source=SourceLog(
                code=GeoSource.IFC_PARTIAL_UNRESOLVED_CRS,
                name="auto_local2global_failed",
                approximate=False,
                messages=messages,
            ),
        )

    try:
        out_matrix = _scale_matrix_project_units_to_crs_units(
            matrix_project_units=np.asarray(base_matrix, dtype=float),
            project_unit_m=project_unit_m,
            crs_unit_m=crs_unit_m,
        )
    except Exception as exc:
        _append(messages, f"Scaling project-units matrix to CRS units failed: {exc}")
        return GeoTransformResult(
            crs=_to_crs_ref(pyproj_crs, name, wkt),
            matrix=None,
            project_unit_m=project_unit_m,
            crs_unit_m=crs_unit_m,
            source=SourceLog(
                code=GeoSource.IFC_PARTIAL_UNRESOLVED_CRS,
                name="matrix_scaling_failed",
                approximate=False,
                messages=messages,
            ),
        )

    _check_vertical_unit_consistency(pyproj_crs, crs_unit_m, messages)

    source_code = (
        GeoSource.IFC_MAPCONVERSION_EPSG
        if authority and code
        else GeoSource.IFC_MAPCONVERSION_WKT
    )
    source_name = (
        "ifc_mapconversion_epsg" if authority and code else "ifc_mapconversion_wkt"
    )
    _append(messages, f"CRS discovered via {discovery.via}.")
    _append(
        messages,
        "Base matrix taken from auto_local2global(..., should_return_in_map_units=False).",
    )
    _append(
        messages,
        "Final matrix scaled from project units to CRS units using pyproj CRS axis unit.",
    )

    return GeoTransformResult(
        crs=_to_crs_ref(pyproj_crs, name, wkt),
        matrix=out_matrix,
        project_unit_m=project_unit_m,
        crs_unit_m=crs_unit_m,
        source=SourceLog(
            code=source_code,
            name=source_name,
            approximate=False,
            messages=messages,
        ),
    )


def _resolve_ifc_geographic_branch(
    model: ifcopenshell.file,
    discovery: OperationDiscovery,
    project_unit_m: float,
    preferred_projected_crs: CRS | str | int | None,
    messages: list[str],
) -> GeoTransformResult | None:
    """
    Resolves the ``IfcGeographicCRS`` branch into a derived projected result.

    This function handles cases where the IFC contains a geographic target CRS
    and an ``IfcRigidOperation`` anchor, but the downstream workflow requires a
    projected CRS for point cloud export and comparison.

    The function:
    - parses the source geographic CRS;
    - extracts the geographic anchor from the rigid operation;
    - converts the anchor to WGS84 for AOI-based projected CRS selection;
    - chooses or accepts a projected CRS;
    - transforms the anchor into the projected CRS;
    - builds an approximate uniform affine matrix from project/world coordinates
        to the derived projected CRS.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.
    discovery : OperationDiscovery
        Previously discovered operation/CRS bundle for a geographic
                target CRS.
    project_unit_m : float
        Size of one project unit in meters.
    preferred_projected_crs : CRS | str | int | None
        Optional caller-provided projected CRS to use
                instead of automatic selection.
    messages : list[str]
        Mutable log message list.

    Returns
    -------
    GeoTransformResult | None
        Approximate projected result if the branch can
            be resolved; otherwise ``None``.
    """
    name = discovery.name
    wkt = discovery.wkt
    authority, code = _parse_authority_code(name)
    source_geog_crs = _build_pyproj_crs(authority, code, name, wkt)
    if source_geog_crs is None:
        _append(
            messages, "IfcGeographicCRS found, but pyproj could not parse Name/WKT."
        )
        return None

    anchor_raw = _extract_geographic_operation_anchor(discovery.op_raw)
    if anchor_raw is None:
        _append(
            messages,
            "IfcGeographicCRS branch requires IfcRigidOperation with FirstCoordinate/SecondCoordinate/Height.",
        )
        return None

    lon_src, lat_src, h_src = anchor_raw

    try:
        to_wgs84 = Transformer.from_crs(
            source_geog_crs, CRS.from_epsg(4326), always_xy=True
        )
        lon_wgs84, lat_wgs84, _ = to_wgs84.transform(lon_src, lat_src, h_src)
    except Exception as exc:
        _append(
            messages,
            f"Failed to convert geographic anchor to WGS84 for AOI search: {exc}",
        )
        return None

    projected_crs, selection_mode = _choose_projected_crs(
        lon_wgs84_deg=float(lon_wgs84),
        lat_wgs84_deg=float(lat_wgs84),
        source_geog_crs=source_geog_crs,
        preferred_projected_crs=preferred_projected_crs,
        messages=messages,
    )
    if projected_crs is None:
        return None

    crs_unit_m = _get_crs_horizontal_unit_m(projected_crs)
    if crs_unit_m is None:
        _append(messages, "Chosen projected CRS has no resolvable horizontal unit.")
        return None

    try:
        to_projected = Transformer.from_crs(
            source_geog_crs, projected_crs, always_xy=True
        )
        x0, y0, z0 = to_projected.transform(lon_src, lat_src, h_src)
    except Exception as exc:
        _append(
            messages,
            f"Failed to transform IfcGeographicCRS anchor into projected CRS: {exc}",
        )
        return None

    anchor_model_world = _get_project_origin_world(model, messages)
    scale = project_unit_m / crs_unit_m
    out_matrix = _make_uniform_affine(
        anchor_model_xyz=np.asarray(anchor_model_world, dtype=float),
        anchor_target_xyz=np.asarray([float(x0), float(y0), float(z0)], dtype=float),
        scale=scale,
    )
    _check_vertical_unit_consistency(projected_crs, crs_unit_m, messages)

    _append(messages, f"CRS discovered via {discovery.via}.")
    _append(
        messages,
        "IfcRigidOperation provides only translation in the target geographic CRS; no rotation/distortion is available.",
    )
    _append(
        messages,
        "Approximate projected matrix built from project/WCS origin anchor and derived projected CRS.",
    )
    _append(messages, f"Projected CRS selection mode: {selection_mode}.")

    return GeoTransformResult(
        crs=_to_crs_ref(
            projected_crs, projected_crs.to_string(), projected_crs.to_wkt()
        ),
        matrix=out_matrix,
        project_unit_m=project_unit_m,
        crs_unit_m=crs_unit_m,
        source=SourceLog(
            code=GeoSource.IFC_GEOGRAPHIC_DERIVED_PROJECTED,
            name="ifc_geographic_derived_projected",
            approximate=True,
            messages=messages,
        ),
    )


def _resolve_site_fallback(
    model: ifcopenshell.file,
    project_unit_m: float,
    preferred_projected_crs: CRS | str | int | None,
    messages: list[str],
) -> GeoTransformResult | None:
    """
    Resolves the ``IfcSite``-based fallback branch.

    This branch is used when no authoritative coordinate operation can be
    resolved from the IFC, but the file contains site latitude/longitude data.

    The function:
    - finds an ``IfcSite``;
    - reads ``RefLatitude``, ``RefLongitude``, and ``RefElevation``;
    - resolves the site local origin in model/project coordinates;
    - chooses or accepts a projected CRS;
    - transforms the WGS84 site anchor into the projected CRS;
    - builds an approximate affine matrix from site/project coordinates to the
        chosen projected CRS.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.
    project_unit_m : float
        Size of one project unit in meters.
    preferred_projected_crs : CRS | str | int | None
        Optional caller-provided projected CRS to use
                instead of automatic selection.
    messages : list[str]
        Mutable log message list.

    Returns
    -------
    GeoTransformResult | None
        Approximate projected fallback result if the
            site anchor can be resolved; otherwise ``None``.
    """
    sites = _safe_by_type(model, "IfcSite")
    if not sites:
        _append(messages, "IfcSite not found.")
        return None

    if len(sites) > 1:
        _append(
            messages,
            "Multiple IfcSite instances found; using the first one for fallback.",
        )

    site = sites[0]
    anchor_wgs84 = _extract_ifcsite_anchor_wgs84(site)
    if anchor_wgs84 is None:
        _append(messages, "IfcSite fallback requires RefLatitude and RefLongitude.")
        return None

    lon_wgs84, lat_wgs84, h_wgs84 = anchor_wgs84
    source_geog_crs = CRS.from_epsg(4326)

    projected_crs, selection_mode = _choose_projected_crs(
        lon_wgs84_deg=lon_wgs84,
        lat_wgs84_deg=lat_wgs84,
        source_geog_crs=source_geog_crs,
        preferred_projected_crs=preferred_projected_crs,
        messages=messages,
    )
    if projected_crs is None:
        return None

    crs_unit_m = _get_crs_horizontal_unit_m(projected_crs)
    if crs_unit_m is None:
        _append(messages, "Chosen projected CRS has no resolvable horizontal unit.")
        return None

    try:
        transformer = Transformer.from_crs(
            source_geog_crs, projected_crs, always_xy=True
        )
        x0, y0, z0 = transformer.transform(lon_wgs84, lat_wgs84, h_wgs84)
    except Exception as exc:
        _append(
            messages,
            f"Failed to transform IfcSite WGS84 anchor into projected CRS: {exc}",
        )
        return None

    anchor_model_world = _get_site_origin_world(model, site, messages)
    scale = project_unit_m / crs_unit_m
    out_matrix = _make_uniform_affine(
        anchor_model_xyz=np.asarray(anchor_model_world, dtype=float),
        anchor_target_xyz=np.asarray([float(x0), float(y0), float(z0)], dtype=float),
        scale=scale,
    )
    _check_vertical_unit_consistency(projected_crs, crs_unit_m, messages)

    _append(
        messages,
        "IfcSite fallback uses RefLatitude/RefLongitude/RefElevation for the origin of the site local placement.",
    )
    _append(
        messages,
        "Approximate projected matrix built from site placement origin and derived/projected CRS.",
    )
    _append(messages, f"Projected CRS selection mode: {selection_mode}.")

    return GeoTransformResult(
        crs=_to_crs_ref(
            projected_crs, projected_crs.to_string(), projected_crs.to_wkt()
        ),
        matrix=out_matrix,
        project_unit_m=project_unit_m,
        crs_unit_m=crs_unit_m,
        source=SourceLog(
            code=GeoSource.SITE_WGS84_DERIVED_PROJECTED,
            name="site_wgs84_derived_projected",
            approximate=True,
            messages=messages,
        ),
    )


# =========================
# Public entry point
# =========================


def resolve_geo_transform(
    model: ifcopenshell.file,
    preferred_projected_crs: CRS | str | int | None = None,
) -> GeoTransformResult:
    """
    Resolves a project/world - to - CRS transformation from an IFC model.

    This is the public entry point of the georeferencing pipeline. It attempts
    to produce a consistent output contract containing:
    - resolved CRS metadata;
    - 4x4 matrix from project/world coordinates to CRS coordinates;
    - project unit size in meters;
    - CRS unit size in meters;
    - source log describing how the result was obtained.

    Resolution order:
    1. authoritative projected CRS branch;
    2. geographic CRS branch with derived projected fallback;
    3. ``IfcSite``-based fallback;
    4. no-real-coordinates result.

    Parameters
    ----------
    model : ifcopenshell.file
        Open IFC model.
    preferred_projected_crs : CRS | str | int | None
        Optional projected CRS to force in geographic
                and site fallback branches. This is recommended when the target scan
                CRS is already known.

    Returns
    -------
    GeoTransformResult
        Final pipeline result. If no real-world coordinates
            can be resolved, the result contains ``crs=None`` and ``matrix=None``.
    """
    messages: list[str] = []

    try:
        project_unit_m = float(ifcunit.calculate_unit_scale(model))
    except Exception as exc:
        return GeoTransformResult(
            crs=None,
            matrix=None,
            project_unit_m=1.0,
            crs_unit_m=None,
            source=SourceLog(
                code=GeoSource.IFC_PARTIAL_UNRESOLVED_CRS,
                name="project_unit_resolution_failed",
                approximate=False,
                messages=[f"Failed to calculate project unit scale: {exc}"],
            ),
        )

    try:
        helmert = ifcgeo.get_helmert_transformation_parameters(model)
    except Exception as exc:
        helmert = None
        _append(messages, f"get_helmert_transformation_parameters failed: {exc}")

    discovery = _discover_operation_bundle(model)

    if helmert is not None and discovery is not None:
        _append(messages, "Helmert/map conversion parameters found in IFC.")

        if discovery.kind == "projected":
            return _resolve_projected_main_branch(
                model, discovery, project_unit_m, messages
            )

        if discovery.kind == "geographic":
            result = _resolve_ifc_geographic_branch(
                model=model,
                discovery=discovery,
                project_unit_m=project_unit_m,
                preferred_projected_crs=preferred_projected_crs,
                messages=messages,
            )
            if result is not None:
                return result
            _append(
                messages,
                "IfcGeographicCRS branch could not be resolved; trying IfcSite fallback.",
            )

        else:
            _append(
                messages,
                f"Unsupported or unknown target CRS kind: {discovery.kind}; trying IfcSite fallback.",
            )
    else:
        _append(
            messages,
            "No authoritative map conversion / target CRS bundle found in IFC; trying IfcSite fallback.",
        )

    site_result = _resolve_site_fallback(
        model=model,
        project_unit_m=project_unit_m,
        preferred_projected_crs=preferred_projected_crs,
        messages=messages,
    )
    if site_result is not None:
        return site_result

    _append(messages, "No real-world coordinate reference could be resolved.")
    return GeoTransformResult(
        crs=None,
        matrix=None,
        project_unit_m=project_unit_m,
        crs_unit_m=None,
        source=SourceLog(
            code=GeoSource.NO_REAL_COORDS,
            name="no_real_coords_project_units",
            approximate=False,
            messages=messages,
        ),
    )
