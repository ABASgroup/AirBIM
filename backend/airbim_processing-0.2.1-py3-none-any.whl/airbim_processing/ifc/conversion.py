"""
An algorithm for converting an IFC project into a LAZ point cloud with raycasting support.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
import multiprocessing
from pathlib import Path
from typing import Any

import ifcopenshell
import ifcopenshell.geom as ifcgeom
import laspy
import numpy as np
import open3d as o3d

try:
    import cupy as cp
    import cupyx
except Exception:
    cp = None
    cupyx = None

try:
    import torch as _torch

    torch: Any = _torch
except Exception:
    torch = None


DEFAULT_IFCGEOM_SETTINGS: list[tuple[str, object]] = [
    ("use-world-coords", True),
    ("convert-back-units", False),
    ("iterator-output", 0),
    ("triangulation-type", 0),
    ("dimensionality", 1),
    ("disable-opening-subtractions", False),
    ("weld-vertices", True),
    ("no-normals", True),
    ("generate-uvs", False),
    ("apply-default-materials", False),
    ("mesher-linear-deflection", 0.001),
    ("mesher-angular-deflection", 0.3),
    ("context-identifiers", ["Body"]),
]

_SIDE_RING_POSE_COUNT = 16
_TOP_RING_POSE_COUNT = 8
_VISIBILITY_BATCH_POINT_LIMIT = 1_000_000
_PLAIN_WRITE_BATCH_POINT_LIMIT = 1_000_000
_VISIBILITY_POSE_BLOCK_SIZE = 8
_RAYCAST_LOCAL_COORD_THRESHOLD_M = 100_000.0
_GPU_SAMPLING_POINT_THRESHOLD = 50_000
_GPU_VISIBILITY_POINT_THRESHOLD = 20_000
_GPU_TRANSFORM_POINT_THRESHOLD = 200_000

_VEGETATION_MARKERS = ("m_rpc tree",)

_VEGETATION_CLASSES = (
    "IfcPlantElement",
    "IfcGeographicElement",
)

_HUMAN_OR_VEHICLE_MARKERS = (
    "m_rpc male",
    "m_rpc female",
    "m_rpc beetle",
)


@dataclass
class IfcConversionResult:
    """
    Detailed execution statistics and metadata for IFC to LAZ conversion.

    Attributes
    ----------
    point_count : int
        Final total number of points successfully written to the LAZ file.
    processed_elements : int
        Total number of IFC physical elements initially picked up for processing.
    meshed_elements : int
        Number of IFC elements whose geometry was successfully converted to a mesh.
    sampled_elements : int
        Number of elements from which points were successfully generated.
    skipped_elements : int
        Number of elements skipped (e.g., due to parsing errors, filtering or zero area).
    bad_geometry_elements : int
        Count of elements whose IFC geometry representation was corrupt or unparsable.
    zero_area_elements : int
        Count of elements whose triangulated meshes evaluated to a surface area of zero.
    ifc_type_to_class : dict
        A dictionary mapping processed IFC entity types (e.g., 'IfcWall', 'IfcSlab')
        to their corresponding counts or classifications.
    mins : list of float
        Minimum spatial coordinates [X, Y, Z] of the generated point cloud's bounding box.
    maxs : list of float
        Maximum spatial coordinates [X, Y, Z] of the generated point cloud's bounding box.
    scales : list of float
        Scale factors [X, Y, Z] applied to coordinates for compression inside the LAZ.
    offsets : list of float
        Coordinate translation offsets [X, Y, Z] written to the LAZ header.
    visibility_enabled : bool
        True if raycasting visibility filtering was applied to remove internal points.
    visibility_backend : str or None
        The backend engine used for raycasting (e.g., "open3d"), or None if filtering was disabled.
    uav_pose_count : int
        The total number of camera/UAV positions used to perform visibility tests.
    sampled_point_count_before_visibility : int
        The raw count of points sampled on surfaces before occlusion testing.
    visible_point_count_after_visibility : int
        The count of points that survived the visibility test (should match `point_count`).
    """

    point_count: int
    processed_elements: int
    meshed_elements: int
    sampled_elements: int
    skipped_elements: int
    bad_geometry_elements: int
    zero_area_elements: int
    ifc_type_to_class: dict
    mins: list[float]
    maxs: list[float]
    scales: list[float]
    offsets: list[float]
    visibility_enabled: bool
    visibility_backend: str | None
    uav_pose_count: int
    sampled_point_count_before_visibility: int
    visible_point_count_after_visibility: int


@dataclass
class SceneElement:
    ifc_type: str
    class_id: int
    guid: str | None
    area_m2: float
    target_point_count: int = 0
    sampling_identity_u64: int = 0
    vertices_world_f64: np.ndarray | None = None
    faces_i32: np.ndarray | None = None
    triangle_area_cdf_f64: np.ndarray | None = None

    def __post_init__(self) -> None:
        """
        Compute area and validate shape metrics automatically after initialization.
        """
        if self.vertices_world_f64 is not None:
            self.vertices_world_f64 = np.asarray(
                self.vertices_world_f64, dtype=np.float64
            ).reshape(-1, 3)

        if self.faces_i32 is not None:
            self.faces_i32 = np.asarray(self.faces_i32, dtype=np.int32).reshape(-1, 3)

        if self.triangle_area_cdf_f64 is not None:
            self.triangle_area_cdf_f64 = np.asarray(
                self.triangle_area_cdf_f64, dtype=np.float64
            ).reshape(-1)

        if (
            self.area_m2 <= 0
            and self.vertices_world_f64 is not None
            and self.faces_i32 is not None
            and len(self.faces_i32) > 0
        ):
            self.area_m2 = _compute_mesh_area_m2(
                self.vertices_world_f64, self.faces_i32
            )


@dataclass
class LazWriteState:
    header_offsets: np.ndarray
    laz_scales: np.ndarray
    point_count: int = 0
    mins: np.ndarray | None = None
    maxs: np.ndarray | None = None


def _torch_cuda_available() -> bool:
    """
    Check if PyTorch is available and CUDA is enabled.

    Returns
    -------
    bool
        True if torch and CUDA are available, otherwise False.
    """
    return torch is not None and bool(torch.cuda.is_available())


def _get_torch_cuda_device() -> Any:
    """
    Get the default PyTorch CUDA device context.

    Returns
    -------
    torch.device
        CUDA device 'cuda:0'.

    Raises
    ------
    RuntimeError
        If PyTorch or CUDA is not available.
    """
    if not _torch_cuda_available():
        raise RuntimeError("CUDA-enabled torch is required for this path")
    return torch.device("cuda:0")


def _torch_generator_seed(random_seed: int, sampling_identity_u64: int) -> int:
    """
    Generate an integer deterministic seed for the Torch generator.

    Parameters
    ----------
    random_seed : int
        Base random seed provided by the user.
    sampling_identity_u64 : int
        A unique 64-bit integer identity for the item being sampled.

    Returns
    -------
    int
        A 64-bit bounded seed valid for torch generators.
    """
    return int(_mix_u64_seed(random_seed, sampling_identity_u64) & ((1 << 63) - 1))


def _cupy_cuda_available() -> bool:
    """
    Check if CuPy is available and a CUDA graphical device operates properly.

    Returns
    -------
    bool
        True if CuPy is available and has an active device, otherwise False.
    """
    if cp is None:
        return False
    try:
        return int(cp.cuda.runtime.getDeviceCount()) > 0
    except Exception:
        return False


def _normalize_geom_settings_params(
    geom_settings_params: (
        list[tuple[str, object]] | tuple[tuple[str, object], ...] | None
    ),
) -> dict[str, object]:
    """
    Convert a list/tuple of raw setting parameters to a dictionary.

    Parameters
    ----------
    geom_settings_params : list[tuple[str, object]] | tuple[tuple[str, object], ...] | None
        Input settings parameters overrides, or None to use default.

    Returns
    -------
    dict[str, object]
        Normalized dictionary with configurations.

    Raises
    ------
    TypeError
        If the given settings overrides are not a list or tuple.
    """
    items = (
        DEFAULT_IFCGEOM_SETTINGS
        if geom_settings_params is None
        else geom_settings_params
    )

    if not isinstance(items, (list, tuple)):
        raise TypeError(
            "geom_settings_params must be a list/tuple of (setting_name, setting_value)"
        )

    normalized: dict[str, object] = {}
    for idx, item in enumerate(items, start=1):
        if not isinstance(item, (list, tuple)) or len(item) != 2:
            raise ValueError(
                f"Each item in geom_settings_params must be pair (name, value). Bad item #{idx}: {item!r}"
            )
        name, value = item
        if not isinstance(name, str) or not name.strip():
            raise ValueError(
                f"Setting name at item #{idx} must be non-empty string. Got: {name!r}"
            )
        normalized[name] = value

    return normalized


def _validate_geom_settings_params(params: dict[str, object]) -> None:
    """
    Validate the dictionary of semantic configuration for IfcGeom.

    Parameters
    ----------
    params : dict[str, object]
        A configuration settings associative mapping.

    Raises
    ------
    ValueError
        If crucial constraints aren't met (e.g. world coordinates missing, convert_back_units enabled).
    TypeError
        If context-identifiers is inappropriately structured.
    """
    if params.get("use-world-coords", True) is not True:
        raise ValueError(
            "ifc_to_laz expects ifcgeom setting 'use-world-coords' == True"
        )

    if params.get("convert-back-units", False) is not False:
        raise ValueError(
            "ifc_to_laz expects ifcgeom setting 'convert-back-units' == False"
        )

    context_identifiers = params.get("context-identifiers", ["Body"])
    if context_identifiers is not None and not isinstance(
        context_identifiers, (list, tuple)
    ):
        raise TypeError("'context-identifiers' must be list/tuple or None")


def _build_ifcgeom_settings(
    geom_settings_params: (
        list[tuple[str, object]] | tuple[tuple[str, object], ...] | None
    ),
    body_context_only: bool,
) -> ifcgeom.settings:
    """
    Initialize and return configuration settings for the IfcGeom module.

    Parameters
    ----------
    geom_settings_params : list[tuple[str, object]] | tuple[tuple[str, object], ...] | None
        A collection of configuration adjustments.
    body_context_only : bool
        If True, restrict output processing to 'Body' represented geometries.

    Returns
    -------
    ifcgeom.settings
        Configured `ifcgeom.settings` object to construct geometries appropriately.
    """
    normalized = _normalize_geom_settings_params(geom_settings_params)
    _validate_geom_settings_params(normalized)

    settings = ifcgeom.settings()
    for setting_name, setting_value in normalized.items():
        if setting_name == "context-identifiers":
            continue
        settings.set(setting_name, setting_value)  # type: ignore[arg-type]

    if body_context_only:
        try:
            settings.set(
                "context-identifiers", normalized.get("context-identifiers", ["Body"])
            )
        except Exception:
            pass

    return settings


def _joined_context_text_fields(elem: Any) -> str:
    """
    Combine 'Name' and 'ObjectType' string properties of an IFC element for evaluation.

    Parameters
    ----------
    elem : Any
        An IFC elements generic Python object model.

    Returns
    -------
    str
        Space-separated lowercase accumulation of its textual descriptors.
    """
    text_fields = [
        getattr(elem, "Name", None),
        getattr(elem, "ObjectType", None),
    ]
    return " ".join(str(x).lower() for x in text_fields if x)


def _is_vegetation(elem: Any) -> bool:
    """
    Determine if an IFC element is categorizable as vegetation.

    Parameters
    ----------
    elem : Any
        The IFC element object.

    Returns
    -------
    bool
        True if the object resolves to a kind of vegetation, false otherwise.
    """
    try:
        if elem.is_a() in _VEGETATION_CLASSES:
            return True
    except Exception:
        pass

    joined = _joined_context_text_fields(elem)
    return any(marker in joined for marker in _VEGETATION_MARKERS)


def _is_human_or_vehicle(elem: Any) -> bool:
    """
    Determine if an IFC element belongs to a human or vehicle character category.

    Parameters
    ----------
    elem : Any
        The IFC element object.

    Returns
    -------
    bool
        True if the object possesses a human/vehicle tag marker.
    """
    joined = _joined_context_text_fields(elem)
    return any(marker in joined for marker in _HUMAN_OR_VEHICLE_MARKERS)


def _is_context_object(elem: Any) -> bool:
    """
    Determine if the associated element is a situational context object (vegetation, vehicles).

    Parameters
    ----------
    elem : Any
        The IFC element to assess.

    Returns
    -------
    bool
        True when object evaluates as general environmental context.
    """
    return _is_vegetation(elem) or _is_human_or_vehicle(elem)


def _collect_physical_elements(
    ifc_file: ifcopenshell.file,
    remove_context_objects: bool = True,
) -> list[Any]:
    """
    Collect physically plausible mesh-producing elements extracted from the main IFC structure.

    Parameters
    ----------
    ifc_file : ifcopenshell.file
        The loaded root IFC file.
    remove_context_objects : bool, default True
        Whether environmental elements (trees, vehicles) should be excluded.

    Returns
    -------
    list[Any]
        A list array of unparsed raw generic IFC element objects.
    """
    elements: list[Any] = []
    for elem in ifc_file.by_type("IfcElement"):
        try:
            if elem.is_a("IfcOpeningElement"):
                continue
            if elem.is_a("IfcVirtualElement"):
                continue
            if elem.is_a("IfcFurnishingElement"):
                continue
            if remove_context_objects and _is_context_object(elem):
                continue
        except Exception:
            pass

        if getattr(elem, "Representation", None) is None:
            continue

        elements.append(elem)
    return elements


def _adapt_transform_for_meter_inputs(
    global_matrix: np.ndarray, project_unit_m: float
) -> np.ndarray:
    """
    Adjust an incoming geographic affine matrix considering millimeter conversions to map correctly.

    Parameters
    ----------
    global_matrix : np.ndarray
        4x4 initial coordinate transformation format constraint.
    project_unit_m : float
        Numerical measurement for base units per meter.

    Returns
    -------
    np.ndarray
        Adjusted (scaled) 4x4 matrix for meter-scale conversion execution.

    Raises
    ------
    ValueError
        In cases of mismatching structure shape or illogical dimensions values.
    """
    if global_matrix.shape != (4, 4):
        raise ValueError("global_matrix must have shape (4, 4)")
    if project_unit_m <= 0:
        raise ValueError("project_unit_m must be positive")

    meters_to_project = np.eye(4, dtype=np.float64)
    scale = 1.0 / project_unit_m
    meters_to_project[0, 0] = scale
    meters_to_project[1, 1] = scale
    meters_to_project[2, 2] = scale
    return global_matrix @ meters_to_project


def _apply_transform(
    points_xyz: np.ndarray, matrix_4x4: np.ndarray | None
) -> np.ndarray:
    """
    Morph a block sequence of Euclidean coordinates respecting a globally defined 4x4 coordinate plane matrix.

    Parameters
    ----------
    points_xyz : np.ndarray
        Raw incoming points sequence.
    matrix_4x4 : np.ndarray | None
        Application 4x4 matrix, None for empty operations bypass.

    Returns
    -------
    np.ndarray
        Positioned point clouds block.

    Raises
    ------
    ValueError
        Throws error mapping exceptions on shape format anomalies.
    """
    if matrix_4x4 is None:
        return points_xyz

    if matrix_4x4.shape != (4, 4):
        raise ValueError("global_matrix must have shape (4, 4)")

    points_xyz = np.asarray(points_xyz, dtype=np.float64).reshape(-1, 3)
    linear = np.asarray(matrix_4x4[:3, :3], dtype=np.float64)
    translation = np.asarray(matrix_4x4[:3, 3], dtype=np.float64)

    if _torch_cuda_available() and len(points_xyz) >= _GPU_TRANSFORM_POINT_THRESHOLD:
        device = _get_torch_cuda_device()
        points_t = torch.from_numpy(np.ascontiguousarray(points_xyz)).to(
            device=device, dtype=torch.float64
        )
        linear_t = torch.from_numpy(np.ascontiguousarray(linear)).to(
            device=device, dtype=torch.float64
        )
        translation_t = torch.from_numpy(np.ascontiguousarray(translation)).to(
            device=device, dtype=torch.float64
        )
        transformed_t = points_t @ linear_t.T + translation_t
        return transformed_t.cpu().numpy()

    return points_xyz @ linear.T + translation


def _build_iterator(
    settings: ifcgeom.settings,
    ifc_file: ifcopenshell.file,
    include_elements: list[Any],
    num_threads: int,
):
    """
    Build a multiprocessor sequence generator over evaluated IFC files components.

    Parameters
    ----------
    settings : ifcgeom.settings
        Settings object configured for parsing instructions processing.
    ifc_file : ifcopenshell.file
        Raw extracted representation.
    include_elements : list[Any]
        A pre-curated collection slice constraints reference array.
    num_threads : int
        Amount of process mapping lines to employ.

    Returns
    -------
    ifcgeom.iterator
        Prepared C++ backed iteration logic flow structure wrapper.

    Raises
    ------
    RuntimeError
        If iterator initialization fails internally sequentially.
    """
    iterator = ifcgeom.iterator(
        settings,
        ifc_file,
        include=include_elements,
        num_threads=num_threads,
    )
    if not iterator.initialize():
        raise RuntimeError("IfcOpenShell geometry iterator failed to initialize")
    return iterator


def _resolve_shape_metadata(
    shape: Any, ifc_file: ifcopenshell.file
) -> tuple[str, str | None]:
    """
    Gather general properties directly tied to evaluated internal iteration instances.

    Parameters
    ----------
    shape : Any
        Topologic parsed output format instance.
    ifc_file : ifcopenshell.file
        Parent environment parsing collection to cross-query.

    Returns
    -------
    tuple[str, str | None]
        IfcClassType parameter evaluation with guid identifier attached.
    """
    ifc_type = "Unknown"
    guid = getattr(shape, "guid", None)
    try:
        elem = None
        if guid:
            elem = ifc_file.by_guid(guid)
        elif hasattr(shape, "id"):
            elem = ifc_file.by_id(shape.id)

        if elem is not None:
            ifc_type = elem.is_a()
            guid = guid or getattr(elem, "GlobalId", None)
    except Exception:
        pass

    return ifc_type, guid


def _entity_instance_id(elem: Any) -> int | None:
    """
    Extract intrinsic numeric identifier code.

    Parameters
    ----------
    elem : Any
        Topologic elements sequence.

    Returns
    -------
    int | None
        Internal identifier representation mapping link.
    """
    elem_id = getattr(elem, "id", None)
    if callable(elem_id):
        try:
            elem_id = elem_id()
        except Exception:
            return None
    if isinstance(elem_id, int):
        return elem_id
    return None


def _build_element_metadata_index(
    include_elements: list[Any],
) -> tuple[dict[str, tuple[str, str | None]], dict[int, tuple[str, str | None]]]:
    """
    Prepare GUID / ID resolution mapping indexes for performance-optimized search parsing.

    Parameters
    ----------
    include_elements : list[Any]
        Included arrays representing processing structures contexts.

    Returns
    -------
    tuple[dict[str, tuple[str, str | None]], dict[int, tuple[str, str | None]]]
        Lookup mappings for GUID tracking and underlying model integer values mappings.
    """
    guid_to_meta: dict[str, tuple[str, str | None]] = {}
    id_to_meta: dict[int, tuple[str, str | None]] = {}

    for elem in include_elements:
        try:
            ifc_type = elem.is_a()
        except Exception:
            ifc_type = "Unknown"

        guid = getattr(elem, "GlobalId", None)
        meta = (ifc_type, guid)

        if isinstance(guid, str) and guid and guid not in guid_to_meta:
            guid_to_meta[guid] = meta

        elem_id = _entity_instance_id(elem)
        if elem_id is not None and elem_id not in id_to_meta:
            id_to_meta[elem_id] = meta

    return guid_to_meta, id_to_meta


def _resolve_shape_metadata_from_index(
    shape: Any,
    guid_to_meta: dict[str, tuple[str, str | None]],
    id_to_meta: dict[int, tuple[str, str | None]],
) -> tuple[str, str | None] | None:
    """
    Query resolved indexing maps for specific extracted model component metadata sets.

    Parameters
    ----------
    shape : Any
        Targeted object shape representation mapping.
    guid_to_meta : dict[str, tuple[str, str | None]]
        Globally unique ID indexing map array.
    id_to_meta : dict[int, tuple[str, str | None]]
        Internal identification index sequence base mapping array.

    Returns
    -------
    tuple[str, str | None] | None
        The resolved type identifier and GUID, alternatively None when indexing misses context mapping.
    """
    guid = getattr(shape, "guid", None)
    if isinstance(guid, str) and guid:
        meta = guid_to_meta.get(guid)
        if meta is not None:
            return meta[0], guid

    shape_id = getattr(shape, "id", None)
    if isinstance(shape_id, int):
        meta = id_to_meta.get(shape_id)
        if meta is not None:
            ifc_type, indexed_guid = meta
            return ifc_type, guid or indexed_guid

    return None


def _extract_shape_geometry(shape: Any) -> tuple[np.ndarray, np.ndarray]:
    """
    Collect vertices and mapping sequence from ifcopenshell processed C++ geometries outputs.

    Parameters
    ----------
    shape : Any
        Parsed structure to extract values mapping properties from.

    Returns
    -------
    tuple[np.ndarray, np.ndarray]
        Arrays for evaluated points positioning matrices alongside sequence structures mapping.
    """
    geom = shape.geometry
    verts = np.asarray(geom.verts, dtype=np.float64).reshape(-1, 3)
    faces = np.asarray(geom.faces, dtype=np.int32).reshape(-1, 3)
    return verts, faces


def _compute_triangle_areas(vertices: np.ndarray, faces: np.ndarray) -> np.ndarray:
    """
    Evaluate structural mesh triangles array measurements mathematically cross product mapping context.

    Parameters
    ----------
    vertices : np.ndarray
        Array context defining mesh positions arrays.
    faces : np.ndarray
        Topologic mapping configuration structures linking positions sequence array context.

    Returns
    -------
    np.ndarray
        Float dimensions list referencing explicit area amounts of each respective triangulated sequence.

    Raises
    ------
    ValueError
        Throws error explicitly if arrays are mismatching sizes mapping operations sequences evaluations.
    """
    if len(vertices) == 0 or len(faces) == 0:
        return np.empty(0, dtype=np.float64)

    triangles = np.asarray(vertices, dtype=np.float64)[faces]
    cross_products = np.cross(
        triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0]
    )
    return 0.5 * np.linalg.norm(cross_products, axis=1)


def _compute_mesh_area_m2(vertices: np.ndarray, faces: np.ndarray) -> float:
    """
    Accumulate area dimensional properties.

    Parameters
    ----------
    vertices : np.ndarray
        Vertex locations.
    faces : np.ndarray
        Triangulated faces mapping.

    Returns
    -------
    float
        Total metric area measurement.
    """
    return float(_compute_triangle_areas(vertices, faces).sum())


def _build_triangle_area_cdf(triangle_areas: np.ndarray) -> np.ndarray:
    """
    Compile cumulative distribution function evaluating sequence area boundaries.

    Parameters
    ----------
    triangle_areas : np.ndarray
        Calculated sizes list attributes.

    Returns
    -------
    np.ndarray
        CDF probabilities values.
    """
    triangle_areas = np.asarray(triangle_areas, dtype=np.float64).reshape(-1)
    if len(triangle_areas) == 0:
        return np.empty(0, dtype=np.float64)

    triangle_area_cdf = np.cumsum(triangle_areas, dtype=np.float64)
    triangle_area_cdf[-1] = float(triangle_area_cdf[-1])
    return triangle_area_cdf


def _hash_bytes_to_u64(*parts: bytes) -> int:
    """
    Produce a u64 blake2b hash of the parts.

    Parameters
    ----------
    parts : bytes
        List of byte elements to hash.

    Returns
    -------
    int
        Hash representation.
    """
    digest = hashlib.blake2b(digest_size=8)
    for part in parts:
        digest.update(part)
    return int.from_bytes(digest.digest(), byteorder="little", signed=False)


def _compute_scene_element_sampling_identity(
    ifc_type: str,
    guid: str | None,
    vertices_world_f64: np.ndarray,
    faces_i32: np.ndarray,
) -> int:
    """
    Produce a deterministic identity representation.

    Parameters
    ----------
    ifc_type : str
        IFC element type.
    guid : str | None
        Globally unique identifier.
    vertices_world_f64 : np.ndarray
        Array of vertices in world coordinates.
    faces_i32 : np.ndarray
        Array of facial indices making up the geometry.

    Returns
    -------
    int
        Unsigned 64-bit hash identity.
    """
    if guid:
        return _hash_bytes_to_u64(
            ifc_type.encode("utf-8"),
            b"\0",
            guid.encode("utf-8"),
        )

    vertices_world_f64 = np.ascontiguousarray(vertices_world_f64, dtype=np.float64)
    faces_i32 = np.ascontiguousarray(faces_i32, dtype=np.int32)
    return _hash_bytes_to_u64(
        ifc_type.encode("utf-8"),
        b"\0",
        vertices_world_f64.view(np.uint8).tobytes(),
        b"\0",
        faces_i32.view(np.uint8).tobytes(),
    )


def _mix_u64_seed(random_seed: int, sampling_identity_u64: int) -> int:
    """
    Produce a mixed 64-bit seed from a random seed and sampling identity.

    Parameters
    ----------
    random_seed : int
        User-provided random seed.
    sampling_identity_u64 : int
        Identity hash of the scene element.

    Returns
    -------
    int
        Mixed deterministic 64-bit integer.
    """
    mask = (1 << 64) - 1
    x = (int(random_seed) ^ int(sampling_identity_u64) ^ 0x9E3779B97F4A7C15) & mask
    x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & mask
    x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & mask
    x = (x ^ (x >> 31)) & mask
    return x


def _assign_class_id(
    ifc_type: str, ifc_type_to_class: dict[str, int], next_class_id: int
) -> tuple[int, int]:
    """
    Retrieve or assign a dense class ID for a newly encountered IFC type string.

    Parameters
    ----------
    ifc_type : str
        The IFC type (e.g. 'IfcWall').
    ifc_type_to_class : dict[str, int]
        Mapping from IFC types to byte-sized integer IDs.
    next_class_id : int
        The sequential fallback identifier to assign.

    Returns
    -------
    tuple[int, int]
        Current assigned class ID and the numeric ID to test next time.
    """
    if ifc_type not in ifc_type_to_class:
        ifc_type_to_class[ifc_type] = next_class_id
        next_class_id = min(255, next_class_id + 1)
    return ifc_type_to_class[ifc_type], next_class_id


def _build_scene_element(
    shape: Any,
    ifc_file: ifcopenshell.file,
    guid_to_meta: dict[str, tuple[str, str | None]],
    id_to_meta: dict[int, tuple[str, str | None]],
    ifc_type_to_class: dict[str, int],
    next_class_id: int,
) -> tuple[SceneElement | None, int, bool]:
    """
    Construct a managed generic wrapper capturing geometry arrays and metrics.

    Parameters
    ----------
    shape : Any
        Topologic instance containing geometries properties.
    ifc_file : ifcopenshell.file
        Original parsed file.
    guid_to_meta : dict[str, tuple[str, str | None]]
        Mapping of globally unique identifiers to type metadata.
    id_to_meta : dict[int, tuple[str, str | None]]
        Mapping of IFC entities inner IDs to types.
    ifc_type_to_class : dict[str, int]
        Lookup translating class identifiers to dataset classification bytes.
    next_class_id : int
        Incrementor tracking unassigned IFC type encounters.

    Returns
    -------
    tuple[SceneElement | None, int, bool]
        Extracted element wrapped object, updated class index incrementor, and a failure validation flag.
    """
    indexed_metadata = _resolve_shape_metadata_from_index(
        shape=shape,
        guid_to_meta=guid_to_meta,
        id_to_meta=id_to_meta,
    )
    if indexed_metadata is None:
        ifc_type, guid = _resolve_shape_metadata(shape, ifc_file)
    else:
        ifc_type, guid = indexed_metadata
    current_class_id, next_class_id = _assign_class_id(
        ifc_type, ifc_type_to_class, next_class_id
    )

    try:
        vertices_f64, faces_i32 = _extract_shape_geometry(shape)
    except Exception:
        return None, next_class_id, True

    if len(vertices_f64) == 0 or len(faces_i32) == 0:
        return None, next_class_id, False

    triangle_areas = _compute_triangle_areas(vertices_f64, faces_i32)
    area_m2 = float(triangle_areas.sum())
    triangle_area_cdf_f64 = _build_triangle_area_cdf(triangle_areas)
    sampling_identity_u64 = _compute_scene_element_sampling_identity(
        ifc_type=ifc_type,
        guid=guid,
        vertices_world_f64=vertices_f64,
        faces_i32=faces_i32,
    )

    return (
        SceneElement(
            ifc_type=ifc_type,
            class_id=current_class_id,
            guid=guid,
            area_m2=area_m2,
            sampling_identity_u64=sampling_identity_u64,
            vertices_world_f64=vertices_f64,
            faces_i32=faces_i32,
            triangle_area_cdf_f64=triangle_area_cdf_f64,
        ),
        next_class_id,
        False,
    )


def _compute_sample_count(
    area_m2: float, density_points_per_m2: float, min_points_per_element: int
) -> tuple[int, bool]:
    """
    Compute target random distributions relying on area metrics limits.

    Parameters
    ----------
    area_m2 : float
        Surface geometrical measured bounds area.
    density_points_per_m2 : float
        The desired sample density.
    min_points_per_element : int
        Fallback minimum boundary limit.

    Returns
    -------
    tuple[int, bool]
        Count representation and a zero-area evaluation indicator.
    """
    n_points = int(math.ceil(area_m2 * density_points_per_m2))
    zero_area_element = False

    if area_m2 > 0 and min_points_per_element > 0:
        n_points = max(n_points, min_points_per_element)
    elif area_m2 <= 1e-9:
        zero_area_element = True

    return n_points, zero_area_element


def _sample_scene_element_points(
    scene_element: SceneElement,
    random_seed: int | None = None,
) -> np.ndarray:
    """
    Compute distribution point sequences via face probabilities.

    Parameters
    ----------
    scene_element : SceneElement
        Target wrapped parsed elements.
    random_seed : int | None
        Seed value ensuring sampling limits stability.

    Returns
    -------
    np.ndarray
        Array configuration with point vertices.
    """
    if scene_element.target_point_count <= 0:
        return np.empty((0, 3), dtype=np.float64)

    if (
        scene_element.vertices_world_f64 is None
        or scene_element.faces_i32 is None
        or scene_element.triangle_area_cdf_f64 is None
    ):
        return np.empty((0, 3), dtype=np.float64)

    if len(scene_element.triangle_area_cdf_f64) == 0:
        return np.empty((0, 3), dtype=np.float64)

    if (
        _torch_cuda_available()
        and scene_element.target_point_count >= _GPU_SAMPLING_POINT_THRESHOLD
    ):
        device = _get_torch_cuda_device()
        generator = None
        if random_seed is not None:
            generator = torch.Generator(device=device)
            generator.manual_seed(
                _torch_generator_seed(random_seed, scene_element.sampling_identity_u64)
            )

        triangle_area_cdf_t = torch.from_numpy(
            np.ascontiguousarray(scene_element.triangle_area_cdf_f64, dtype=np.float64)
        ).to(device=device, dtype=torch.float64)
        faces_t = torch.from_numpy(
            np.ascontiguousarray(scene_element.faces_i32, dtype=np.int64)
        ).to(device=device, dtype=torch.int64)
        vertices_t = torch.from_numpy(
            np.ascontiguousarray(scene_element.vertices_world_f64, dtype=np.float64)
        ).to(device=device, dtype=torch.float64)

        random_values = (
            torch.rand(
                scene_element.target_point_count,
                device=device,
                dtype=torch.float64,
                generator=generator,
            )
            * triangle_area_cdf_t[-1]
        )
        face_indices = torch.searchsorted(
            triangle_area_cdf_t, random_values, right=True
        )
        face_indices = torch.clamp(
            face_indices, 0, len(scene_element.faces_i32) - 1
        ).to(torch.int64)
        sampled_faces = faces_t.index_select(0, face_indices)
        triangles = vertices_t[sampled_faces]

        u = torch.rand(
            scene_element.target_point_count,
            device=device,
            dtype=torch.float64,
            generator=generator,
        )
        v = torch.rand(
            scene_element.target_point_count,
            device=device,
            dtype=torch.float64,
            generator=generator,
        )
        sqrt_u = torch.sqrt(u)

        w0 = 1.0 - sqrt_u
        w1 = sqrt_u * (1.0 - v)
        w2 = sqrt_u * v
        sampled_points_t = (
            triangles[:, 0] * w0.unsqueeze(1)
            + triangles[:, 1] * w1.unsqueeze(1)
            + triangles[:, 2] * w2.unsqueeze(1)
        )
        return sampled_points_t.cpu().numpy()

    if random_seed is None:
        rng = np.random.default_rng()
    else:
        rng = np.random.default_rng(
            _mix_u64_seed(random_seed, scene_element.sampling_identity_u64)
        )

    random_values = (
        rng.random(scene_element.target_point_count)
        * scene_element.triangle_area_cdf_f64[-1]
    )
    face_indices = np.searchsorted(
        scene_element.triangle_area_cdf_f64, random_values, side="right"
    )
    face_indices = np.clip(face_indices, 0, len(scene_element.faces_i32) - 1)
    sampled_faces = scene_element.faces_i32[face_indices]
    triangles = scene_element.vertices_world_f64[sampled_faces]

    u_np = rng.random(scene_element.target_point_count)
    v_np = rng.random(scene_element.target_point_count)
    sqrt_u_np = np.sqrt(u_np)

    w0_np = 1.0 - sqrt_u_np
    w1_np = sqrt_u_np * (1.0 - v_np)
    w2_np = sqrt_u_np * v_np
    return np.asarray(
        triangles[:, 0] * w0_np[:, None]
        + triangles[:, 1] * w1_np[:, None]
        + triangles[:, 2] * w2_np[:, None],
        dtype=np.float64,
    )


def _extract_scene_elements(
    ifc_file: ifcopenshell.file,
    settings: ifcgeom.settings,
    include_elements: list[Any],
    num_threads: int,
) -> tuple[list[SceneElement], dict[str, Any]]:
    """
    Iterate over parsed IFC structures extracting usable meshes to memory.

    Parameters
    ----------
    ifc_file : ifcopenshell.file
        Main loaded model.
    settings : ifcgeom.settings
        IfcGeom settings overrides.
    include_elements : list[Any]
        List of IFC elements to process.
    num_threads : int
        Thread quantities limit counts.

    Returns
    -------
    tuple[list[SceneElement], dict[str, Any]]
        Extracted scene elements and stats dictionary.
    """
    guid_to_meta, id_to_meta = _build_element_metadata_index(include_elements)
    iterator = _build_iterator(
        settings=settings,
        ifc_file=ifc_file,
        include_elements=include_elements,
        num_threads=num_threads,
    )

    scene_elements: list[SceneElement] = []
    processed_elements = 0
    meshed_elements = 0
    bad_geometry_elements = 0
    zero_area_elements = 0
    ifc_type_to_class: dict[str, int] = {}
    next_class_id = 2  # class_id 1 reserved for emissions and noise for pdal pipeline

    while True:
        shape = iterator.get()
        processed_elements += 1

        scene_element, next_class_id, bad_geometry = _build_scene_element(
            shape=shape,
            ifc_file=ifc_file,
            guid_to_meta=guid_to_meta,
            id_to_meta=id_to_meta,
            ifc_type_to_class=ifc_type_to_class,
            next_class_id=next_class_id,
        )
        if bad_geometry:
            bad_geometry_elements += 1

        if scene_element is not None:
            meshed_elements += 1
            if scene_element.area_m2 <= 1e-9:
                zero_area_elements += 1
            scene_elements.append(scene_element)

        if not iterator.next():
            break

    return scene_elements, {
        "processed_elements": processed_elements,
        "meshed_elements": meshed_elements,
        "bad_geometry_elements": bad_geometry_elements,
        "zero_area_elements": zero_area_elements,
        "ifc_type_to_class": ifc_type_to_class,
    }


def _prepare_scene_elements_for_sampling(
    scene_elements: list[SceneElement],
    density_points_per_m2: float,
    min_points_per_element: int,
) -> int:
    """
    Initializes element sample count counts target.

    Parameters
    ----------
    scene_elements : list[SceneElement]
        List of parsed scene wrappers.
    density_points_per_m2 : float
        Points expected per square meter.
    min_points_per_element : int
        Fallback lower limit for output points.

    Returns
    -------
    int
        Amount of zero area encountered elements.
    """
    zero_area_elements = 0
    for scene_element in scene_elements:
        target_point_count, zero_area_element = _compute_sample_count(
            area_m2=scene_element.area_m2,
            density_points_per_m2=density_points_per_m2,
            min_points_per_element=min_points_per_element,
        )
        scene_element.target_point_count = target_point_count
        if zero_area_element:
            zero_area_elements += 1
    return zero_area_elements


def _build_open3d_raycasting_scene(
    scene_elements: list[SceneElement],
    raycast_anchor_world_f64: np.ndarray | None,
) -> Any:
    """
    Populates an Open3D computational visibility mesh.

    Parameters
    ----------
    scene_elements : list[SceneElement]
        Extracted sequences of bounding representations.
    raycast_anchor_world_f64 : np.ndarray | None
        Position adjustments ensuring coordinate limits stability.

    Returns
    -------
    Any
        Open3D compatible raycast target.
    """
    scene = o3d.t.geometry.RaycastingScene()
    for scene_element in scene_elements:
        if scene_element.vertices_world_f64 is None or scene_element.faces_i32 is None:
            continue

        vertices_local_f32 = _localize_to_f32(
            scene_element.vertices_world_f64,
            raycast_anchor_world_f64,
        )

        tensor_mesh = o3d.t.geometry.TriangleMesh()
        tensor_mesh.vertex.positions = o3d.core.Tensor(
            vertices_local_f32,
            dtype=o3d.core.Dtype.Float32,
        )
        tensor_mesh.triangle.indices = o3d.core.Tensor(
            np.asarray(scene_element.faces_i32, dtype=np.uint32),
            dtype=o3d.core.Dtype.UInt32,
        )
        scene.add_triangles(tensor_mesh)

    return scene


def _compute_scene_bbox(
    scene_elements: list[SceneElement],
) -> tuple[np.ndarray, np.ndarray]:
    """
    Compute overall bounding box limits for the parsed sequence.

    Parameters
    ----------
    scene_elements : list[SceneElement]
        Constructed element limits targets.

    Returns
    -------
    tuple[np.ndarray, np.ndarray]
        Vector minimum and maximum bound coordinates arrays.
    """
    if not scene_elements:
        raise ValueError("scene_elements must not be empty")

    first_vertices = scene_elements[0].vertices_world_f64
    if first_vertices is None or len(first_vertices) == 0:
        raise ValueError("scene_elements must contain vertex data")

    bbox_min = first_vertices.min(axis=0)
    bbox_max = first_vertices.max(axis=0)

    for scene_element in scene_elements[1:]:
        verts = scene_element.vertices_world_f64
        if verts is None or len(verts) == 0:
            continue
        bbox_min = np.minimum(bbox_min, verts.min(axis=0))
        bbox_max = np.maximum(bbox_max, verts.max(axis=0))

    return bbox_min, bbox_max


def _compute_bbox_corners(bbox_min: np.ndarray, bbox_max: np.ndarray) -> np.ndarray:
    """
    Calculate bounding box 8 corners limits representation.

    Parameters
    ----------
    bbox_min : np.ndarray
        Minimum bounding box.
    bbox_max : np.ndarray
        Maximum bounding box.

    Returns
    -------
    np.ndarray
        Corners coordinates.
    """
    return np.asarray(
        [
            [bbox_min[0], bbox_min[1], bbox_min[2]],
            [bbox_min[0], bbox_min[1], bbox_max[2]],
            [bbox_min[0], bbox_max[1], bbox_min[2]],
            [bbox_min[0], bbox_max[1], bbox_max[2]],
            [bbox_max[0], bbox_min[1], bbox_min[2]],
            [bbox_max[0], bbox_min[1], bbox_max[2]],
            [bbox_max[0], bbox_max[1], bbox_min[2]],
            [bbox_max[0], bbox_max[1], bbox_max[2]],
        ],
        dtype=np.float64,
    )


def _compute_laz_header_offsets(
    scene_elements: list[SceneElement],
    global_matrix: np.ndarray | None,
) -> np.ndarray:
    """
    Calculate origin transformation limits based on minimal bounding arrays constraints.

    Parameters
    ----------
    scene_elements : list[SceneElement]
        Constructed constraints parameters.
    global_matrix : np.ndarray | None
        Matrix mappings evaluations bounds variables.

    Returns
    -------
    np.ndarray
        Offsets bounds limitations.
    """
    if not scene_elements:
        return np.zeros(3, dtype=np.float64)

    bbox_min, bbox_max = _compute_scene_bbox(scene_elements)
    bbox_corners_world = _compute_bbox_corners(bbox_min=bbox_min, bbox_max=bbox_max)
    transformed_corners = _apply_transform(bbox_corners_world, global_matrix)
    return np.asarray(transformed_corners.min(axis=0), dtype=np.float64)


def _resolve_raycast_anchor_world_f64(
    bbox_min: np.ndarray,
    bbox_max: np.ndarray,
) -> np.ndarray | None:
    """
    Resolve Raycast translation anchor for centering coordinates.

    Parameters
    ----------
    bbox_min : np.ndarray
        Minimum bounding box.
    bbox_max : np.ndarray
        Maximum bounding box.

    Returns
    -------
    np.ndarray | None
        The computed raycast anchor bounds.
    """
    max_abs_coord = max(
        float(np.abs(bbox_min).max()),
        float(np.abs(bbox_max).max()),
    )
    if max_abs_coord < _RAYCAST_LOCAL_COORD_THRESHOLD_M:
        return None
    return 0.5 * (bbox_min + bbox_max)


def _localize_to_f32(
    points_world_f64: np.ndarray,
    raycast_anchor_world_f64: np.ndarray | None,
) -> np.ndarray:
    """
    Convert points to local space in 32-bit float for hardware raycasting.

    Parameters
    ----------
    points_world_f64 : np.ndarray
        Absolute positions.
    raycast_anchor_world_f64 : np.ndarray | None
        Position to relative-anchor the coordinates against.

    Returns
    -------
    np.ndarray
        Float32 point cloud coordinates.
    """
    points_world_f64 = np.asarray(points_world_f64, dtype=np.float64)
    if raycast_anchor_world_f64 is not None:
        points_world_f64 = points_world_f64 - raycast_anchor_world_f64
    return points_world_f64.astype(np.float32, copy=False)


def _generate_uav_poses_from_bbox(
    bbox_min: np.ndarray, bbox_max: np.ndarray
) -> np.ndarray:
    """
    Synthesize mock sensors positions enclosing the bounding box structure.

    Parameters
    ----------
    bbox_min : np.ndarray
        Bounding box minimum corner.
    bbox_max : np.ndarray
        Bounding box maximum corner.

    Returns
    -------
    np.ndarray
        Array containing ringed elevation drone positions.
    """
    bbox_center = 0.5 * (bbox_min + bbox_max)
    bbox_size = bbox_max - bbox_min

    dx, dy, dz = bbox_size[0], bbox_size[1], bbox_size[2]
    diag_half = 0.5 * math.hypot(dx, dy)
    side_radius = max(diag_half * 1.35, diag_half + 2.0)
    azimuths = np.linspace(
        0.0, 2.0 * math.pi, num=_SIDE_RING_POSE_COUNT, endpoint=False, dtype=np.float64
    )
    heights = np.array(
        [
            bbox_min[2] + 0.25 * dz,
            bbox_min[2] + 0.55 * dz,
            bbox_min[2] + 0.85 * dz,
        ],
        dtype=np.float64,
    )
    top_altitude = bbox_max[2] + max(2.0, 0.5 * dz)
    top_ring_radius = 0.5 * side_radius

    poses: list[list[float]] = []
    for height in heights:
        for azimuth in azimuths:
            poses.append(
                [
                    bbox_center[0] + side_radius * math.cos(float(azimuth)),
                    bbox_center[1] + side_radius * math.sin(float(azimuth)),
                    float(height),
                ]
            )

    poses.append([float(bbox_center[0]), float(bbox_center[1]), float(top_altitude)])
    for azimuth in np.linspace(
        0.0, 2.0 * math.pi, num=_TOP_RING_POSE_COUNT, endpoint=False, dtype=np.float64
    ):
        poses.append(
            [
                bbox_center[0] + top_ring_radius * math.cos(float(azimuth)),
                bbox_center[1] + top_ring_radius * math.sin(float(azimuth)),
                float(top_altitude),
            ]
        )

    return np.asarray(poses, dtype=np.float64)


def _validate_uav_poses_world_m(
    uav_poses_world_m: np.ndarray | None,
) -> np.ndarray | None:
    """
    Validate sequence of expected camera poses formatting.

    Parameters
    ----------
    uav_poses_world_m : np.ndarray | None
        Positions mappings.

    Returns
    -------
    np.ndarray | None
        Checked matrix sequences or None.
    """
    if uav_poses_world_m is None:
        return None

    poses = np.asarray(uav_poses_world_m, dtype=np.float64)
    if poses.ndim != 2 or poses.shape[1] != 3:
        raise ValueError("uav_poses_world_m must have shape (K, 3)")
    if len(poses) == 0:
        raise ValueError("uav_poses_world_m must not be empty")
    if not np.isfinite(poses).all():
        raise ValueError("uav_poses_world_m must contain only finite values")
    return poses


def _resolve_uav_poses_world_m(
    bbox_min: np.ndarray,
    bbox_max: np.ndarray,
    uav_poses_world_m: np.ndarray | None,
    auto_generate_uav_poses: bool,
) -> np.ndarray:
    """
    Determines fallback drone sensor orientations via procedural geometry bounding.

    Parameters
    ----------
    bbox_min : np.ndarray
        Bounding constraints minimum.
    bbox_max : np.ndarray
        Bounding constraints maximum.
    uav_poses_world_m : np.ndarray | None
        Fallback mapping values.
    auto_generate_uav_poses : bool
        Flag indicating generation toggle.

    Returns
    -------
    np.ndarray
        Sensors pose configurations.
    """
    poses = _validate_uav_poses_world_m(uav_poses_world_m)
    if poses is not None:
        return poses
    if not auto_generate_uav_poses:
        raise ValueError(
            "visibility_filter=True requires uav_poses_world_m or auto_generate_uav_poses=True"
        )

    return _generate_uav_poses_from_bbox(bbox_min=bbox_min, bbox_max=bbox_max)


def _compute_visibility_mask_open3d(
    points_local_f32: np.ndarray,
    scene: Any,
    sensor_poses_local_f32: np.ndarray,
    eps_m: float,
    chunk_size: int,
) -> np.ndarray:
    """
    Calculate boolean masks masking internally occluded IFC points.

    Parameters
    ----------
    points_local_f32 : np.ndarray
        Query target nodes.
    scene : Any
        Open3D raycasting targets.
    sensor_poses_local_f32 : np.ndarray
        Locations simulating ray origins.
    eps_m : float
        Tolerance boundaries measurements threshold.
    chunk_size : int
        Maximum size per evaluation step.

    Returns
    -------
    np.ndarray
        Boolean arrays retaining visible parts limits true values.
    """
    if eps_m < 0:
        raise ValueError("visibility_eps_m must be >= 0")
    if chunk_size <= 0:
        raise ValueError("visibility_chunk_size must be > 0")

    points_local_f32 = np.asarray(points_local_f32, dtype=np.float32).reshape(-1, 3)
    sensor_poses_local_f32 = np.asarray(
        sensor_poses_local_f32, dtype=np.float32
    ).reshape(-1, 3)

    if (
        _cupy_cuda_available()
        and len(points_local_f32) >= _GPU_VISIBILITY_POINT_THRESHOLD
    ):
        poses_cp = cp.asarray(sensor_poses_local_f32, dtype=cp.float32)
        visible_mask = np.zeros(len(points_local_f32), dtype=bool)

        for start in range(0, len(points_local_f32), chunk_size):
            end = min(start + chunk_size, len(points_local_f32))
            chunk_points_cp = cp.asarray(points_local_f32[start:end], dtype=cp.float32)
            chunk_visible_cp = cp.zeros(len(chunk_points_cp), dtype=cp.bool_)

            for pose_start in range(
                0, len(sensor_poses_local_f32), _VISIBILITY_POSE_BLOCK_SIZE
            ):
                remaining_idx_cp = cp.flatnonzero(~chunk_visible_cp)
                if int(remaining_idx_cp.size) == 0:
                    break

                pose_block_cp = poses_cp[
                    pose_start : pose_start + _VISIBILITY_POSE_BLOCK_SIZE
                ]
                targets_cp = chunk_points_cp[remaining_idx_cp]
                deltas_cp = (
                    targets_cp[cp.newaxis, :, :] - pose_block_cp[:, cp.newaxis, :]
                )
                distances_cp = cp.linalg.norm(deltas_cp, axis=2)

                near_any_mask_cp = (distances_cp <= eps_m).any(axis=0)
                if bool(near_any_mask_cp.any()):
                    chunk_visible_cp[remaining_idx_cp[near_any_mask_cp]] = True

                valid_mask_cp = ~near_any_mask_cp
                if not bool(valid_mask_cp.any()):
                    continue

                valid_targets_idx = cp.asnumpy(remaining_idx_cp[valid_mask_cp])
                valid_deltas_cp = deltas_cp[:, valid_mask_cp, :]
                valid_distances_cp = distances_cp[:, valid_mask_cp]
                pose_block_valid_cp = pose_block_cp

                origins_cp = cp.broadcast_to(
                    pose_block_valid_cp[:, cp.newaxis, :],
                    valid_deltas_cp.shape,
                )
                rays_cp = cp.concatenate([origins_cp, valid_deltas_cp], axis=2).reshape(
                    -1, 6
                )

                if cupyx is not None:
                    rays_cpu = cupyx.empty_pinned(rays_cp.shape, dtype=np.float32)
                    valid_distances_cpu = cupyx.empty_pinned(
                        valid_distances_cp.shape, dtype=np.float32
                    )
                    cp.asnumpy(rays_cp, out=rays_cpu)
                    cp.asnumpy(valid_distances_cp, out=valid_distances_cpu)
                else:
                    rays_cpu = cp.asnumpy(rays_cp)
                    valid_distances_cpu = cp.asnumpy(valid_distances_cp)

                ray_tensor = o3d.core.Tensor(rays_cpu, dtype=o3d.core.Dtype.Float32)
                hits = scene.cast_rays(ray_tensor)
                t_hit = hits["t_hit"].numpy().reshape(len(pose_block_valid_cp), -1)

                target_t = 1.0 - (eps_m / valid_distances_cpu)
                hit_visible = np.isfinite(t_hit) & (t_hit >= target_t)
                point_visible = hit_visible.any(axis=0)
                if np.any(point_visible):
                    chunk_visible_cp[valid_targets_idx[point_visible]] = True

            visible_mask[start:end] = cp.asnumpy(chunk_visible_cp)

        return visible_mask

    if (
        _torch_cuda_available()
        and len(points_local_f32) >= _GPU_VISIBILITY_POINT_THRESHOLD
    ):
        device = _get_torch_cuda_device()
        poses_t = torch.from_numpy(np.ascontiguousarray(sensor_poses_local_f32)).to(
            device=device, dtype=torch.float32
        )
        visible_mask = np.zeros(len(points_local_f32), dtype=bool)

        for start in range(0, len(points_local_f32), chunk_size):
            end = min(start + chunk_size, len(points_local_f32))
            chunk_points = points_local_f32[start:end]
            chunk_visible = torch.zeros(
                len(chunk_points), dtype=torch.bool, device=device
            )
            points_t = torch.from_numpy(np.ascontiguousarray(chunk_points)).to(
                device=device, dtype=torch.float32
            )

            for pose_start in range(
                0, len(sensor_poses_local_f32), _VISIBILITY_POSE_BLOCK_SIZE
            ):
                remaining_idx = (~chunk_visible).nonzero(as_tuple=True)[0]
                if remaining_idx.numel() == 0:
                    break

                pose_block = poses_t[
                    pose_start : pose_start + _VISIBILITY_POSE_BLOCK_SIZE
                ]
                targets = points_t[remaining_idx]
                deltas = targets.unsqueeze(0) - pose_block.unsqueeze(1)
                distances = torch.linalg.norm(deltas, dim=2)

                near_any_mask = (distances <= eps_m).any(dim=0)
                if near_any_mask.any():
                    chunk_visible[remaining_idx[near_any_mask]] = True

                valid_mask = ~near_any_mask
                if not valid_mask.any():
                    continue

                valid_targets_idx = remaining_idx[valid_mask].cpu().numpy()
                valid_deltas = deltas[:, valid_mask, :].cpu().numpy()
                valid_distances = distances[:, valid_mask].cpu().numpy()
                pose_block_cpu = pose_block.cpu().numpy()
                origins = np.broadcast_to(
                    pose_block_cpu[:, np.newaxis, :],
                    valid_deltas.shape,
                )
                rays = np.concatenate([origins, valid_deltas], axis=2).reshape(-1, 6)
                ray_tensor = o3d.core.Tensor(rays, dtype=o3d.core.Dtype.Float32)
                hits = scene.cast_rays(ray_tensor)
                t_hit = hits["t_hit"].numpy().reshape(len(pose_block_cpu), -1)

                target_t = 1.0 - (eps_m / valid_distances)
                hit_visible = np.isfinite(t_hit) & (t_hit >= target_t)
                point_visible = hit_visible.any(axis=0)
                if np.any(point_visible):
                    chunk_visible[valid_targets_idx[point_visible]] = True

            visible_mask[start:end] = chunk_visible.cpu().numpy()

        return visible_mask

    visible_mask = np.zeros(len(points_local_f32), dtype=bool)

    for start in range(0, len(points_local_f32), chunk_size):
        end = min(start + chunk_size, len(points_local_f32))
        chunk_points = points_local_f32[start:end]
        chunk_visible_np = np.zeros(len(chunk_points), dtype=bool)

        for pose_start in range(
            0, len(sensor_poses_local_f32), _VISIBILITY_POSE_BLOCK_SIZE
        ):
            remaining_idx_np = np.flatnonzero(~chunk_visible_np)
            if len(remaining_idx_np) == 0:
                break

            pose_block_np = sensor_poses_local_f32[
                pose_start : pose_start + _VISIBILITY_POSE_BLOCK_SIZE
            ]
            targets_np = chunk_points[remaining_idx_np]
            # NumPy Broadcasting: pose_block shape (P, 3), targets shape (T, 3) -> deltas shape (P, T, 3)
            deltas_np = targets_np[np.newaxis, :, :] - pose_block_np[:, np.newaxis, :]
            distances_np = np.linalg.norm(deltas_np, axis=2)

            near_mask = distances_np <= eps_m
            near_any_mask = near_mask.any(axis=0)
            if np.any(near_any_mask):
                chunk_visible_np[remaining_idx_np[near_any_mask]] = True

            valid_mask = ~near_any_mask
            if not np.any(valid_mask):
                continue

            valid_targets_idx = remaining_idx_np[valid_mask]
            valid_deltas = deltas_np[:, valid_mask, :]
            valid_distances = distances_np[:, valid_mask]
            origins = np.broadcast_to(
                pose_block_np[:, np.newaxis, :],
                valid_deltas.shape,
            )
            rays = np.concatenate([origins, valid_deltas], axis=2).reshape(-1, 6)
            ray_tensor = o3d.core.Tensor(rays, dtype=o3d.core.Dtype.Float32)
            hits = scene.cast_rays(ray_tensor)
            t_hit = hits["t_hit"].numpy().reshape(len(pose_block_np), -1)

            target_t = 1.0 - (eps_m / valid_distances)
            hit_visible = np.isfinite(t_hit) & (t_hit >= target_t)
            point_visible = hit_visible.any(axis=0)
            if np.any(point_visible):
                chunk_visible_np[valid_targets_idx[point_visible]] = True

        visible_mask[start:end] = chunk_visible_np

    return visible_mask


def _flush_visibility_batch(
    points_buffer: np.ndarray,
    classes_buffer: np.ndarray,
    element_ids_buffer: np.ndarray,
    batch_size: int,
    scene: Any,
    sensor_poses_local_f32: np.ndarray,
    raycast_anchor_world_f64: np.ndarray | None,
    global_matrix: np.ndarray | None,
    visibility_eps_m: float,
    visibility_chunk_size: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Runs batched visibility rays to clear occluded points from buffers.

    Parameters
    ----------
    points_buffer : np.ndarray
        Buffered sequence of extracted geometry coordinates.
    classes_buffer : np.ndarray
        Buffered classification maps.
    element_ids_buffer : np.ndarray
        Buffered scene elements structural indices.
    batch_size : int
        Valid limits indicating usage thresholds.
    scene : Any
        Open3D raycasting topologic index.
    sensor_poses_local_f32 : np.ndarray
        Query positions for camera locations.
    raycast_anchor_world_f64 : np.ndarray | None
        Adjustable anchoring center for visibility limits.
    global_matrix : np.ndarray | None
        Georeferencing coordinates inputs.
    visibility_eps_m : float
        Measurements thickness tolerance limitations.
    visibility_chunk_size : int
        Execution boundaries sizes per iteration chunk.

    Returns
    -------
    tuple[np.ndarray, np.ndarray, np.ndarray]
        Arrays containing valid unoccluded points, related classes, and element identifiers.
    """
    if batch_size <= 0:
        return (
            np.empty((0, 3), dtype=np.float64),
            np.empty(0, dtype=np.uint8),
            np.empty(0, dtype=np.int64),
        )

    points_world_f64 = points_buffer[:batch_size]
    points_local_f32 = _localize_to_f32(points_world_f64, raycast_anchor_world_f64)

    visible_mask = _compute_visibility_mask_open3d(
        points_local_f32=points_local_f32,
        scene=scene,
        sensor_poses_local_f32=sensor_poses_local_f32,
        eps_m=visibility_eps_m,
        chunk_size=visibility_chunk_size,
    )
    visible_points = points_world_f64[visible_mask]
    visible_classes = classes_buffer[:batch_size][visible_mask]
    visible_element_ids = element_ids_buffer[:batch_size][visible_mask]

    if len(visible_points) > 0:
        visible_points = _apply_transform(visible_points, global_matrix)
    return (
        visible_points,
        visible_classes.astype(np.uint8, copy=False),
        visible_element_ids.astype(np.int64, copy=False),
    )


def _build_laz_header_and_open_writer(
    output_laz_path: Path,
    laz_scales: tuple[float, float, float],
    header_offsets: np.ndarray,
) -> tuple[Any, laspy.LasHeader]:
    """
    Initialize LAZ header and open writer for point cloud output.

    Parameters
    ----------
    output_laz_path : Path
        Path to the destination LAZ file.
    laz_scales : tuple[float, float, float]
        Scale factors for coordinates.
    header_offsets : np.ndarray
        Offsets for the bounding box origin.

    Returns
    -------
    tuple[Any, laspy.LasHeader]
        Opened LAZ writer and initialized header.
    """
    header = laspy.LasHeader(point_format=6, version="1.4")
    header.scales = np.asarray(laz_scales, dtype=np.float64)
    header.offsets = np.asarray(header_offsets, dtype=np.float64)
    writer = laspy.open(
        str(output_laz_path),
        mode="w",
        header=header,
        do_compress=True,
    )
    return writer, header


def _write_laz_chunk(
    writer: Any,
    header: laspy.LasHeader,
    points_xyz_chunk: np.ndarray,
    classes_chunk: np.ndarray,
    write_state: LazWriteState,
) -> None:
    """
    Write a chunk of coordinate points into the LAZ document.

    Parameters
    ----------
    writer : Any
        Active LAZ writer object.
    header : laspy.LasHeader
        Record definition constraints schema.
    points_xyz_chunk : np.ndarray
        Coordinates data batch.
    classes_chunk : np.ndarray
        Classification scalar data array.
    write_state : LazWriteState
        Tracker object carrying overall bounds logic.

    Returns
    -------
    None
    """
    if len(points_xyz_chunk) == 0:
        return
    if len(points_xyz_chunk) != len(classes_chunk):
        raise ValueError("points_xyz_chunk and classes_chunk must have the same length")

    points_xyz_chunk = np.asarray(points_xyz_chunk, dtype=np.float64).reshape(-1, 3)
    classes_chunk = np.asarray(classes_chunk, dtype=np.uint8).reshape(-1)

    record = laspy.ScaleAwarePointRecord.zeros(len(points_xyz_chunk), header=header)
    record.x = points_xyz_chunk[:, 0]
    record.y = points_xyz_chunk[:, 1]
    record.z = points_xyz_chunk[:, 2]
    record.classification = classes_chunk
    writer.write_points(record)

    chunk_mins = points_xyz_chunk.min(axis=0)
    chunk_maxs = points_xyz_chunk.max(axis=0)

    if write_state.mins is None:
        write_state.mins = chunk_mins
        write_state.maxs = chunk_maxs
    else:
        assert write_state.mins is not None
        assert write_state.maxs is not None
        write_state.mins = np.minimum(write_state.mins, chunk_mins)
        write_state.maxs = np.maximum(write_state.maxs, chunk_maxs)
    write_state.point_count += len(points_xyz_chunk)


def _flush_plain_batch(
    points_buffer: np.ndarray,
    classes_buffer: np.ndarray,
    batch_size: int,
    global_matrix: np.ndarray | None,
    writer: Any,
    header: laspy.LasHeader,
    write_state: LazWriteState,
) -> None:
    """
    Apply any scaling matrices and write the buffered array chunks dynamically.

    Parameters
    ----------
    points_buffer : np.ndarray
        Internal buffered sampled coordinates.
    classes_buffer : np.ndarray
        Internal buffered generated classifications.
    batch_size : int
        Valid elements count inside the buffers.
    global_matrix : np.ndarray | None
        Affine coordinate transformation.
    writer : Any
        LAZ pipeline output processor object.
    header : laspy.LasHeader
        Laspy document schema.
    write_state : LazWriteState
        Structure bounds tracking system.

    Returns
    -------
    None
    """
    if batch_size <= 0:
        return

    transformed_points = _apply_transform(points_buffer[:batch_size], global_matrix)
    _write_laz_chunk(
        writer=writer,
        header=header,
        points_xyz_chunk=transformed_points,
        classes_chunk=classes_buffer[:batch_size],
        write_state=write_state,
    )


def _sample_elements_without_visibility(
    scene_elements: list[SceneElement],
    global_matrix: np.ndarray | None,
    random_seed: int | None,
    writer: Any,
    header: laspy.LasHeader,
    write_state: LazWriteState,
) -> tuple[int, int]:
    """
    Collect samples unconditionally bypassing visibility calculations.

    Parameters
    ----------
    scene_elements : list[SceneElement]
        Target scene components to process points from.
    global_matrix : np.ndarray | None
        Georeferencing coordinates affine transform.
    random_seed : int | None
        Stable determinism identifier.
    writer : Any
        LAZ recording interface pointing to output file.
    header : laspy.LasHeader
        LAZ document configurations constraints attributes mappings.
    write_state : LazWriteState
        State variable updating bounds during write loops.

    Returns
    -------
    tuple[int, int]
        Total elements processed successfully and valid amounts of mapped samples.
    """
    points_buffer = np.empty((_PLAIN_WRITE_BATCH_POINT_LIMIT, 3), dtype=np.float64)
    classes_buffer = np.empty(_PLAIN_WRITE_BATCH_POINT_LIMIT, dtype=np.uint8)
    batch_size = 0
    sampled_elements = 0
    sampled_point_count_before_visibility = 0

    for scene_element in scene_elements:
        if scene_element.target_point_count <= 0:
            continue

        points = _sample_scene_element_points(
            scene_element=scene_element,
            random_seed=random_seed,
        )
        if len(points) == 0:
            continue

        sampled_point_count_before_visibility += len(points)
        point_start = 0

        while point_start < len(points):
            remaining_capacity = _PLAIN_WRITE_BATCH_POINT_LIMIT - batch_size
            if remaining_capacity == 0:
                _flush_plain_batch(
                    points_buffer=points_buffer,
                    classes_buffer=classes_buffer,
                    batch_size=batch_size,
                    global_matrix=global_matrix,
                    writer=writer,
                    header=header,
                    write_state=write_state,
                )
                batch_size = 0
                remaining_capacity = _PLAIN_WRITE_BATCH_POINT_LIMIT

            take_count = min(remaining_capacity, len(points) - point_start)
            next_batch_size = batch_size + take_count
            point_end = point_start + take_count
            points_buffer[batch_size:next_batch_size] = points[point_start:point_end]
            classes_buffer[batch_size:next_batch_size] = scene_element.class_id
            batch_size = next_batch_size
            point_start = point_end

        sampled_elements += 1

    _flush_plain_batch(
        points_buffer=points_buffer,
        classes_buffer=classes_buffer,
        batch_size=batch_size,
        global_matrix=global_matrix,
        writer=writer,
        header=header,
        write_state=write_state,
    )
    return sampled_elements, sampled_point_count_before_visibility


def _sample_elements_with_visibility(
    scene_elements: list[SceneElement],
    scene: Any,
    sensor_poses_local_f32: np.ndarray,
    raycast_anchor_world_f64: np.ndarray | None,
    global_matrix: np.ndarray | None,
    random_seed: int | None,
    visibility_eps_m: float,
    visibility_chunk_size: int,
    writer: Any,
    header: laspy.LasHeader,
    write_state: LazWriteState,
) -> tuple[int, int, int]:
    """
    Collect samples and remove self-occluded locations via simulated sensing.

    Parameters
    ----------
    scene_elements : list[SceneElement]
        Geometrically prepared representations.
    scene : Any
        Topological target instance.
    sensor_poses_local_f32 : np.ndarray
        Array containing ringed drone positions.
    raycast_anchor_world_f64 : np.ndarray | None
        Bounding calculations stabilization center offset.
    global_matrix : np.ndarray | None
        Global geographic matrix adjustment.
    random_seed : int | None
        Stable determinism identifier.
    visibility_eps_m : float
        Tolerance for visibility bounding overlap.
    visibility_chunk_size : int
        Max internal loop size.
    writer : Any
        Outputs recording sequence pointer.
    header : laspy.LasHeader
        LAZ recording boundaries context.
    write_state : LazWriteState
        State variable updating bounds during write loops.

    Returns
    -------
    tuple[int, int, int]
        Processed elements count, raw sampled count, and retained visible points count.
    """
    visible_element_ids: set[int] = set()
    batch_flush_limit = max(visibility_chunk_size, _VISIBILITY_BATCH_POINT_LIMIT)
    points_buffer = np.empty((batch_flush_limit, 3), dtype=np.float64)
    classes_buffer = np.empty(batch_flush_limit, dtype=np.uint8)
    element_ids_buffer = np.empty(batch_flush_limit, dtype=np.int64)
    batch_size = 0
    next_element_id = 0
    sampled_point_count_before_visibility = 0
    visible_point_count_after_visibility = 0

    for scene_element in scene_elements:
        if scene_element.target_point_count <= 0:
            continue

        points = _sample_scene_element_points(
            scene_element=scene_element,
            random_seed=random_seed,
        )
        if len(points) == 0:
            continue

        sampled_point_count_before_visibility += len(points)
        point_start = 0

        while point_start < len(points):
            remaining_capacity = batch_flush_limit - batch_size
            if remaining_capacity == 0:
                visible_points, visible_classes, flushed_element_ids = (
                    _flush_visibility_batch(
                        points_buffer=points_buffer,
                        classes_buffer=classes_buffer,
                        element_ids_buffer=element_ids_buffer,
                        batch_size=batch_size,
                        scene=scene,
                        sensor_poses_local_f32=sensor_poses_local_f32,
                        raycast_anchor_world_f64=raycast_anchor_world_f64,
                        global_matrix=global_matrix,
                        visibility_eps_m=visibility_eps_m,
                        visibility_chunk_size=visibility_chunk_size,
                    )
                )
                visible_point_count_after_visibility += len(visible_points)
                if len(visible_points) > 0:
                    visible_element_ids.update(np.unique(flushed_element_ids).tolist())
                    _write_laz_chunk(
                        writer=writer,
                        header=header,
                        points_xyz_chunk=visible_points,
                        classes_chunk=visible_classes,
                        write_state=write_state,
                    )
                batch_size = 0
                remaining_capacity = batch_flush_limit

            take_count = min(remaining_capacity, len(points) - point_start)
            next_batch_size = batch_size + take_count
            point_end = point_start + take_count
            points_buffer[batch_size:next_batch_size] = points[point_start:point_end]
            classes_buffer[batch_size:next_batch_size] = scene_element.class_id
            element_ids_buffer[batch_size:next_batch_size] = next_element_id
            batch_size = next_batch_size
            point_start = point_end

        next_element_id += 1

    visible_points, visible_classes, flushed_element_ids = _flush_visibility_batch(
        points_buffer=points_buffer,
        classes_buffer=classes_buffer,
        element_ids_buffer=element_ids_buffer,
        batch_size=batch_size,
        scene=scene,
        sensor_poses_local_f32=sensor_poses_local_f32,
        raycast_anchor_world_f64=raycast_anchor_world_f64,
        global_matrix=global_matrix,
        visibility_eps_m=visibility_eps_m,
        visibility_chunk_size=visibility_chunk_size,
    )
    visible_point_count_after_visibility += len(visible_points)
    if len(visible_points) > 0:
        visible_element_ids.update(np.unique(flushed_element_ids).tolist())
        _write_laz_chunk(
            writer=writer,
            header=header,
            points_xyz_chunk=visible_points,
            classes_chunk=visible_classes,
            write_state=write_state,
        )

    return (
        len(visible_element_ids),
        sampled_point_count_before_visibility,
        visible_point_count_after_visibility,
    )


def ifc_to_laz(
    ifc_file: ifcopenshell.file,
    output_laz_path: str | Path,
    global_matrix: np.ndarray | None,
    project_unit_m: float | None,
    density_points_per_m2: float = 500.0,
    laz_scales: tuple[float, float, float] = (0.001, 0.001, 0.001),
    min_points_per_element: int = 1,
    num_threads: int | None = None,
    body_context_only: bool = True,
    geom_settings_params: (
        list[tuple[str, object]] | tuple[tuple[str, object], ...] | None
    ) = None,
    random_seed: int | None = None,
    visibility_filter: bool = False,
    uav_poses_world_m: np.ndarray | None = None,
    auto_generate_uav_poses: bool = True,
    visibility_eps_m: float = 0.02,
    visibility_chunk_size: int = 100_000,
    remove_context_objects: bool = True,
) -> IfcConversionResult:
    """
    Converts an IFC file to a LAZ point cloud, sampling points on the geometry surfaces.

    Parameters
    ----------
    ifc_file : ifcopenshell.file
        The parsed IFC file object.
    output_laz_path : str | Path
        Path where the generated LAZ file will be stored.
    global_matrix : np.ndarray | None
        A 4x4 transformation matrix for geographic referencing.
    project_unit_m : float | None
        The project units in meters, required if global_matrix is provided.
    density_points_per_m2 : float, default 500.0
        The density of the points per square meter for geometry sampling.
    laz_scales : tuple[float, float, float], default (0.001, 0.001, 0.001)
        The scaling factors for the LAZ coordinates (gives mm precision).
    min_points_per_element : int, default 1
        The minimal amount of points to sample per building element.
    num_threads : int | None, default None
        Number of threads for IFC geometry processing. Uses all cores if None.
    body_context_only : bool, default True
        Whether to process only 'Body' context representation of elements.
    geom_settings_params : list[tuple[str, object]] | tuple[tuple[str, object], ...] | None, default None
        Custom IfcGeom settings overrides.
    random_seed : int | None, default None
        Random seed for reproducible point sampling.
    visibility_filter : bool, default False
        If true, apply raycasting visibility to remove internal points.
    uav_poses_world_m : np.ndarray | None, default None
        UAV poses in world coordinates for visibility raycasting. (not necessary if auto_generate_uav_poses is True)
    auto_generate_uav_poses : bool, default True
        Whether to automatically distribute sensors/UAV poses.
    visibility_eps_m : float, default 0.02
        Tolerance in meters to consider points visible (solves self-occlusion).
    visibility_chunk_size : int, default 100_000
        Size of the chunks used during batched visibility calculations.
    remove_context_objects : bool, default True
        If True, ignores objects like vegetation, humans, and vehicles.

    Returns
    -------
    IfcConversionResult
        An object containing processing statistics like point counts, bounding box, scales, and offsets.

    Raises
    ------
    ValueError
        If numeric parameters are negative, or `project_unit_m` is missing when `global_matrix` is used.
    RuntimeError
        If no mesh elements were extracted, or all points were removed by visibility filtering.

    Examples
    --------
    ```python
    model = ifcopenshell.open("ifc2x3_Myran.ifc")
    geo_result = resolve_geo_transform(model)

    result = ifc_to_laz(
        ifc_file=model,
        output_laz_path="Myran.laz",
        global_matrix=geo_result.matrix,
        project_unit_m=geo_result.project_unit_m,
        density_points_per_m2=500,
        laz_scales=(0.001, 0.001, 0.001),
        visibility_filter=True,
    )
    ```
    """
    if density_points_per_m2 < 0:
        raise ValueError("density_points_per_m2 must be >= 0")
    if min_points_per_element < 0:
        raise ValueError("min_points_per_element must be >= 0")
    if visibility_eps_m < 0:
        raise ValueError("visibility_eps_m must be >= 0")
    if visibility_chunk_size <= 0:
        raise ValueError("visibility_chunk_size must be > 0")
    if random_seed is not None and random_seed < 0:
        raise ValueError("random_seed must be >= 0")

    if global_matrix is not None:
        if project_unit_m is None:
            raise ValueError(
                "project_unit_m must be provided when global_matrix is not None "
                "and geometry is generated in meters."
            )
        global_matrix = _adapt_transform_for_meter_inputs(
            global_matrix=global_matrix,
            project_unit_m=project_unit_m,
        )

    output_laz_path = Path(output_laz_path)
    if num_threads is None:
        num_threads = multiprocessing.cpu_count()

    settings = _build_ifcgeom_settings(
        geom_settings_params=geom_settings_params,
        body_context_only=body_context_only,
    )
    include_elements = _collect_physical_elements(
        ifc_file,
        remove_context_objects=remove_context_objects,
    )
    scene_elements, stats = _extract_scene_elements(
        ifc_file=ifc_file,
        settings=settings,
        include_elements=include_elements,
        num_threads=num_threads,
    )

    processed_elements = int(stats["processed_elements"])
    meshed_elements = int(stats["meshed_elements"])
    bad_geometry_elements = int(stats["bad_geometry_elements"])
    ifc_type_to_class = dict(stats["ifc_type_to_class"])
    zero_area_elements = _prepare_scene_elements_for_sampling(
        scene_elements=scene_elements,
        density_points_per_m2=density_points_per_m2,
        min_points_per_element=min_points_per_element,
    )
    header_offsets = _compute_laz_header_offsets(
        scene_elements=scene_elements,
        global_matrix=global_matrix,
    )
    writer, header = _build_laz_header_and_open_writer(
        output_laz_path=output_laz_path,
        laz_scales=laz_scales,
        header_offsets=header_offsets,
    )
    write_state = LazWriteState(
        header_offsets=np.asarray(header_offsets, dtype=np.float64),
        laz_scales=np.asarray(laz_scales, dtype=np.float64),
    )

    with writer:
        if visibility_filter:
            if not scene_elements:
                raise RuntimeError(
                    "No mesh elements were extracted from the IFC geometry"
                )

            bbox_min, bbox_max = _compute_scene_bbox(scene_elements)
            sensor_poses_world_f64 = _resolve_uav_poses_world_m(
                bbox_min=bbox_min,
                bbox_max=bbox_max,
                uav_poses_world_m=uav_poses_world_m,
                auto_generate_uav_poses=auto_generate_uav_poses,
            )
            raycast_anchor_world_f64 = _resolve_raycast_anchor_world_f64(
                bbox_min=bbox_min,
                bbox_max=bbox_max,
            )
            sensor_poses_local_f32 = _localize_to_f32(
                sensor_poses_world_f64,
                raycast_anchor_world_f64,
            )
            scene = _build_open3d_raycasting_scene(
                scene_elements=scene_elements,
                raycast_anchor_world_f64=raycast_anchor_world_f64,
            )
            uav_pose_count = int(len(sensor_poses_world_f64))
            visibility_backend = "open3d"
            (
                sampled_elements,
                sampled_point_count_before_visibility,
                visible_point_count_after_visibility,
            ) = _sample_elements_with_visibility(
                scene_elements=scene_elements,
                scene=scene,
                sensor_poses_local_f32=sensor_poses_local_f32,
                raycast_anchor_world_f64=raycast_anchor_world_f64,
                global_matrix=global_matrix,
                random_seed=random_seed,
                visibility_eps_m=visibility_eps_m,
                visibility_chunk_size=visibility_chunk_size,
                writer=writer,
                header=header,
                write_state=write_state,
            )
        else:
            uav_pose_count = 0
            visibility_backend = None
            sampled_elements, sampled_point_count_before_visibility = (
                _sample_elements_without_visibility(
                    scene_elements=scene_elements,
                    global_matrix=global_matrix,
                    random_seed=random_seed,
                    writer=writer,
                    header=header,
                    write_state=write_state,
                )
            )
            visible_point_count_after_visibility = sampled_point_count_before_visibility

    if sampled_point_count_before_visibility == 0:
        raise RuntimeError("No points were sampled from the IFC geometry")
    if write_state.point_count == 0:
        if visibility_filter:
            raise RuntimeError(
                "All sampled points were removed by visibility filtering"
            )
        raise RuntimeError("No points were sampled from the IFC geometry")
    if write_state.mins is None or write_state.maxs is None:
        raise RuntimeError("LAZ write state was not populated despite written points")

    skipped_elements = processed_elements - sampled_elements
    return IfcConversionResult(
        point_count=int(write_state.point_count),
        processed_elements=processed_elements,
        meshed_elements=meshed_elements,
        sampled_elements=sampled_elements,
        skipped_elements=skipped_elements,
        bad_geometry_elements=bad_geometry_elements,
        zero_area_elements=zero_area_elements,
        ifc_type_to_class=ifc_type_to_class,
        mins=write_state.mins.tolist(),
        maxs=write_state.maxs.tolist(),
        scales=list(laz_scales),
        offsets=write_state.header_offsets.tolist(),
        visibility_enabled=visibility_filter,
        visibility_backend=visibility_backend,
        uav_pose_count=uav_pose_count,
        sampled_point_count_before_visibility=int(sampled_point_count_before_visibility),
        visible_point_count_after_visibility=int(visible_point_count_after_visibility),
    )
