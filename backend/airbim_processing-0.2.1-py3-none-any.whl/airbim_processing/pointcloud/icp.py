"""
Functions for performing Iterative Closest Point (ICP) alignment between two point clouds.
"""

import logging
from pathlib import Path

import laspy
import numpy as np
import open3d as o3d

logger = logging.getLogger(__name__)


def get_icp_transformation(
    source_xyz: np.ndarray,
    target_xyz: np.ndarray,
    voxel_size: float = 0.2,
    max_corr_distance: float = 5.0,
    max_iterations: int = 150,
) -> tuple[np.ndarray, float, float]:
    """
    Estimate a rigid transformation that aligns one point cloud to another.

    The function optionally scales the source cloud when the covariance-based
    variance ratio suggests a large size mismatch, then downsamples both clouds
    and refines the alignment with point-to-plane ICP.

    Parameters
    ----------
    source_xyz : np.ndarray
        Source point cloud of shape ``(N, 3)``.
    target_xyz : np.ndarray
        Target point cloud of shape ``(M, 3)``.
    voxel_size : float, default=0.2
        Downsampling voxel size in meters.
    max_corr_distance : float, default=5.0
        Maximum correspondence distance used by ICP.
    max_iterations : int, default=150
        Maximum number of ICP iterations.

    Returns
    -------
    tuple[np.ndarray, float, float]
        A tuple containing:
        - Final 4x4 transformation matrix.
        - Fitness score (overlap ratio) from ICP.
        - Inlier RMSE from ICP.

    Raises
    ------
    ValueError
        If the input clouds are empty or invalid for covariance estimation.
    RuntimeError
        If Open3D fails during ICP processing.

    Examples
    --------
    Align a raw cloud to a reference cloud:

    >>> transform, fitness, rmse = get_icp_transformation(source_xyz, target_xyz)
    """
    source_pcd = o3d.geometry.PointCloud()
    source_pcd.points = o3d.utility.Vector3dVector(source_xyz)

    target_pcd = o3d.geometry.PointCloud()
    target_pcd.points = o3d.utility.Vector3dVector(target_xyz)

    source_variance = np.sum(np.var(source_xyz, axis=0))
    target_variance = np.sum(np.var(target_xyz, axis=0))

    scale_factor = float(np.sqrt(target_variance / source_variance))
    logger.info("Calculated invariant scale (target/source): %.6f", scale_factor)

    original_source_center = source_pcd.get_center()

    if abs(scale_factor - 1.0) > 0.1:
        logger.info("Applying source scaling by factor %.6f", scale_factor)
        logger.debug("Original source center: %s", original_source_center)
        source_pcd.scale(scale_factor, center=original_source_center)
    else:
        scale_factor = 1.0

    logger.info("Downsampling clouds with voxel_size=%.3f m", voxel_size)
    source_down = source_pcd.voxel_down_sample(voxel_size)
    target_down = target_pcd.voxel_down_sample(voxel_size)

    source_bb_center = (source_down.get_max_bound() + source_down.get_min_bound()) / 2.0
    target_bb_center = (target_down.get_max_bound() + target_down.get_min_bound()) / 2.0

    source_down.translate(-source_bb_center)
    target_down.translate(-target_bb_center)

    init_transform = np.identity(4)
    logger.info("Initial centroid offset: %s", target_bb_center - source_bb_center)

    source_down.estimate_normals(
        o3d.geometry.KDTreeSearchParamHybrid(radius=voxel_size * 2.0, max_nn=30)
    )
    target_down.estimate_normals(
        o3d.geometry.KDTreeSearchParamHybrid(radius=voxel_size * 2.0, max_nn=30)
    )

    logger.info("Running ICP with max_corr_distance=%.3f m", max_corr_distance)
    icp_result = o3d.pipelines.registration.registration_icp(
        source_down,
        target_down,
        max_corr_distance,
        init_transform,
        o3d.pipelines.registration.TransformationEstimationPointToPlane(),
        o3d.pipelines.registration.ICPConvergenceCriteria(max_iteration=max_iterations),
    )

    logger.info("ICP completed")
    logger.info("ICP fitness: %.4f", icp_result.fitness)
    logger.info("ICP RMSE: %.4f", icp_result.inlier_rmse)

    scale_matrix = np.identity(4)
    if scale_factor != 1.0:
        c = original_source_center
        scale_matrix[0:3, 3] = c - c * scale_factor
        scale_matrix[0:3, 0:3] *= scale_factor

    M_to_origin = np.identity(4)
    M_to_origin[0:3, 3] = -source_bb_center

    M_icp = icp_result.transformation

    M_to_target = np.identity(4)
    M_to_target[0:3, 3] = target_bb_center

    final_transform = M_to_target @ M_icp @ M_to_origin @ scale_matrix

    return final_transform, icp_result.fitness, icp_result.inlier_rmse


def apply_transform(xyz: np.ndarray, transform: np.ndarray) -> np.ndarray:
    """
    Apply a 4x4 transformation matrix to a point array.

    Parameters
    ----------
    xyz : np.ndarray
        Input points of shape ``(N, 3)``.
    transform : np.ndarray
        4x4 transformation matrix.

    Returns
    -------
    np.ndarray
        Transformed points of shape ``(N, 3)``.

    Raises
    ------
    ValueError
        If the input arrays are incompatible with the matrix operation.

    Examples
    --------
    Transform a chunk of points:

    >>> xyz_out = apply_transform(xyz_in, transform)
    """
    xyz_homogeneous = np.hstack((xyz, np.ones((xyz.shape[0], 1), dtype=xyz.dtype)))

    transformed_xyz = xyz_homogeneous.dot(transform.T)

    return transformed_xyz[:, :3]


def save_transformed_laz(
    real_laz_path: str | Path,
    ideal_laz_path: str | Path,
    output_laz_path: str | Path,
    transform: np.ndarray,
) -> None:
    """
    Transform a LAZ file and save it as a new file.

    Parameters
    ----------
    real_laz_path : str | Path
        Path to the source LAZ file that will be transformed.
    ideal_laz_path : str | Path
        Path to the reference LAZ file whose scales and offsets are reused.
    output_laz_path : str | Path
        Path to the output LAZ file.
    transform : np.ndarray
        4x4 transformation matrix.

    Returns
    -------
    None

    Raises
    ------
    OSError
        If one of the LAZ files cannot be opened or written.

    Examples
    --------
    Save a transformed copy of the real cloud:

    >>> transform, fitness, rmse = get_icp_transformation(source_xyz, target_xyz)
    >>> save_transformed_laz("real.laz", "ideal.laz", "real_aligned.laz", transform)
    """
    real_laz_path = Path(real_laz_path)
    ideal_laz_path = Path(ideal_laz_path)
    output_laz_path = Path(output_laz_path)
    logger.info("Saving transformed cloud to %s", output_laz_path)

    with laspy.open(ideal_laz_path) as ref_reader:
        ref_header = ref_reader.header.copy()

    with laspy.open(real_laz_path) as reader:
        header = reader.header.copy()

        header.scales = ref_header.scales
        header.offsets = ref_header.offsets

        with laspy.open(output_laz_path, mode="w", header=header) as writer:
            for pts in reader.chunk_iterator(2_000_000):
                xyz = np.column_stack((pts.x, pts.y, pts.z)).astype(
                    np.float64, copy=False
                )
                xyz_transformed = apply_transform(xyz, transform)

                out_pts = laspy.ScaleAwarePointRecord.zeros(len(pts), header=header)
                out_pts.copy_fields_from(pts)
                out_pts.x = xyz_transformed[:, 0]
                out_pts.y = xyz_transformed[:, 1]
                out_pts.z = xyz_transformed[:, 2]

                writer.write_points(out_pts)
