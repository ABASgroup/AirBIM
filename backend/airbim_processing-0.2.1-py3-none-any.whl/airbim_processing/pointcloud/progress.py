"""
Functions for computing progress between two point clouds, including volume estimation.
"""

import copy
from dataclasses import dataclass
import logging
from pathlib import Path

import laspy
import numpy as np

from .common import build_kdtree, load_xyz_from_laz, query_kdtree
from .icp import apply_transform, get_icp_transformation

logger = logging.getLogger(__name__)


@dataclass
class ProgressStats:
    """
    Computed statistics representing physical and geometric changes between two states.

    Attributes
    ----------
    total_before_points : int
        Total number of points in the initial ("before") point cloud.
    total_after_points : int
        Total number of points in the modified ("after") point cloud.
    removed_points : int
        Count of points identified as removed or excavated from the initial state.
    new_points : int
        Count of points identified as newly added or constructed in the final state.
    removed_volume_m3 : float
        Estimated volume of removed material/components in cubic meters (m³).
    removed_volume_percent : float
        Percentage of removed volume relative to the total volume.
    new_volume_m3 : float
        Estimated volume of newly added material/components in cubic meters (m³).
    new_volume_percent : float
        Percentage of new volume relative to the total volume.
    delta_width : float
        The absolute change in overall width (X-dimension extent) between states.
    delta_length : float
        The absolute change in overall length (Y-dimension extent) between states.
    delta_height : float
        The absolute change in overall height (Z-dimension extent) between states.
    changes_width_range : tuple[float, float, float]
        A tuple of (minimum, maximum, range) bounding the changes along the X-axis.
    changes_length_range : tuple[float, float, float]
        A tuple of (minimum, maximum, range) bounding the changes along the Y-axis.
    changes_height_range : tuple[float, float, float]
        A tuple of (minimum, maximum, range) bounding the changes along the Z-axis.
    """

    total_before_points: int
    total_after_points: int
    removed_points: int
    new_points: int
    removed_volume_m3: float
    removed_volume_percent: float
    new_volume_m3: float
    new_volume_percent: float
    delta_width: float
    delta_length: float
    delta_height: float
    changes_width_range: tuple[float, float, float]
    changes_length_range: tuple[float, float, float]
    changes_height_range: tuple[float, float, float]


def compute_volume(xyz_array: np.ndarray, voxel_size: float = 0.1) -> float:
    """
    Estimate the volume of a point cloud using voxelization.

    Parameters
    ----------
    xyz_array : np.ndarray
        Array of (X, Y, Z) point coordinates.
    voxel_size : float, optional
        Voxel size in meters, by default 0.1.

    Returns
    -------
    float
        The estimated volume in cubic meters.
    """
    if len(xyz_array) == 0:
        return 0.0
    voxels = np.floor(xyz_array / voxel_size).astype(np.int64)
    unique_voxels = np.unique(voxels, axis=0)
    return len(unique_voxels) * (voxel_size**3)


def _process_removed(
    before_path: str | Path,
    after_xyz: np.ndarray,
    output_path: str | Path,
    tolerance: float,
    use_gpu: bool,
    chunk_size: int,
) -> tuple:
    """
    Compare Before to After to find removed and unchanged elements.
    Write the results to output_path.

    Parameters
    ----------
    before_path : str | Path
        Path to the 'before' state LAZ file.
    after_xyz : np.ndarray
        Array of points from the 'after' state.
    output_path : str | Path
        Path to save the output classified points.
    tolerance : float
        Maximum distance threshold to classify points as unchanged.
    use_gpu : bool
        Whether to use GPU acceleration for KDTree operations.
    chunk_size : int
        Buffer chunk size for iterating over points.

    Returns
    -------
    tuple
        A tuple containing:
        - list: A list of NumPy arrays representing points classified as removed.
        - laspy.LasHeader: The generated LAZ header for the written file.
    """
    before_path = Path(before_path)
    output_path = Path(output_path)
    after_tree, on_gpu, gpu_pts = build_kdtree(after_xyz, use_gpu)
    removed_pts = []

    with laspy.open(before_path) as reader_before:
        header = copy.deepcopy(reader_before.header)
        header.point_format = laspy.PointFormat(7)
        header.add_extra_dim(laspy.ExtraBytesParams(name="status", type=np.uint8))

        with laspy.open(output_path, mode="w", header=header) as writer:
            for pts in reader_before.chunk_iterator(chunk_size):
                xyz = np.column_stack((pts.x, pts.y, pts.z)).astype(
                    np.float64, copy=False
                )
                current_count = len(xyz)

                dists, _ = query_kdtree(after_tree, xyz, on_gpu)
                mask_removed = dists > tolerance
                mask_same = dists <= tolerance

                if np.any(mask_removed):
                    removed_pts.append(xyz[mask_removed])

                red = np.zeros(current_count, dtype=np.uint16)
                green = np.zeros(current_count, dtype=np.uint16)
                blue = np.zeros(current_count, dtype=np.uint16)

                red[mask_removed] = 65535
                blue[mask_same] = 65535

                out_pts = laspy.ScaleAwarePointRecord.zeros(
                    current_count, header=header
                )
                out_pts.copy_fields_from(pts)

                out_pts.x = pts.x
                out_pts.y = pts.y
                out_pts.z = pts.z
                out_pts.red = red
                out_pts.green = green
                out_pts.blue = blue

                status = np.zeros(current_count, dtype=np.uint8)
                status[mask_removed] = 1
                out_pts.status = status

                writer.write_points(out_pts)

    if gpu_pts is not None:
        del gpu_pts
    del after_tree

    return removed_pts, header


def _process_new(
    after_path: str | Path,
    before_xyz: np.ndarray,
    output_path: str | Path,
    header: laspy.LasHeader,
    tolerance: float,
    use_gpu: bool,
    chunk_size: int,
    transform_matrix: np.ndarray | None,
) -> list:
    """
    Compare After to Before to find new elements and append to output_path.

    Parameters
    ----------
    after_path : str | Path
        Path to the 'after' state LAZ file.
    before_xyz : np.ndarray
        Array of points from the 'before' state.
    output_path : str | Path
        Path to append the newly identified points.
    header : laspy.LasHeader
        The LAZ file header derived from the removed points step.
    tolerance : float
        Maximum distance threshold to classify points as new.
    use_gpu : bool
        Whether to use GPU acceleration for KDTree operations.
    chunk_size : int
        Buffer chunk size for iterating over points.
    transform_matrix : np.ndarray | None
        An optionally applied 4x4 transformation matrix for accurate alignment.

    Returns
    -------
    list
        A list of NumPy arrays representing points classified as newly added.
    """
    after_path = Path(after_path)
    output_path = Path(output_path)
    before_tree, on_gpu, gpu_pts = build_kdtree(before_xyz, use_gpu)
    new_pts = []

    with laspy.open(output_path, mode="a") as writer:
        with laspy.open(after_path) as reader_after:
            for pts in reader_after.chunk_iterator(chunk_size):
                xyz = np.column_stack((pts.x, pts.y, pts.z)).astype(
                    np.float64, copy=False
                )
                if transform_matrix is not None:
                    xyz = apply_transform(xyz, transform_matrix)

                dists, _ = query_kdtree(before_tree, xyz, on_gpu)
                mask_new = dists > tolerance

                if not np.any(mask_new):
                    continue

                new_xyz = xyz[mask_new]
                new_pts.append(new_xyz)

                new_count = len(new_xyz)
                out_pts = laspy.ScaleAwarePointRecord.zeros(new_count, header=header)

                if transform_matrix is not None:
                    out_pts.x = new_xyz[:, 0]
                    out_pts.y = new_xyz[:, 1]
                    out_pts.z = new_xyz[:, 2]
                else:
                    out_pts.x = pts.x[mask_new]
                    out_pts.y = pts.y[mask_new]
                    out_pts.z = pts.z[mask_new]

                out_pts.red = np.zeros(new_count, dtype=np.uint16)
                out_pts.green = np.full(new_count, 65535, dtype=np.uint16)
                out_pts.blue = np.zeros(new_count, dtype=np.uint16)
                out_pts.status = np.full(new_count, 2, dtype=np.uint8)

                writer.append_points(out_pts)

    if gpu_pts is not None:
        del gpu_pts
    del before_tree

    return new_pts


def compute_progress(
    before_laz_path: str | Path,
    after_laz_path: str | Path,
    output_laz_path: str | Path,
    tolerance: float,
    use_gpu: bool = False,
    chunk_size: int = 1_000_000,
    voxel_size: float = 0.1,
    enable_icp: bool = False,
) -> ProgressStats:
    """
    Calculate the progress between two point clouds (before and after),
    saving the result to a new LAZ file.

    The output point cloud uses colors to indicate the status of points:
    - Green: New elements (present in 'after', absent in 'before').
    - Red: Removed elements (present in 'before', absent in 'after').
    - Blue: Unchanged elements.

    Parameters
    ----------
    before_laz_path : str | Path
        Path to the 'before' state point cloud.
    after_laz_path : str | Path
        Path to the 'after' state point cloud.
    output_laz_path : str | Path
        Path to save the resulting annotated point cloud.
    tolerance : float
        Maximum distance to consider points unchanged.
    use_gpu : bool, optional
        Whether to accelerate nearest-neighbor searches on GPU, by default False.
    chunk_size : int, optional
        Chunk size for file reads, by default 1_000_000.
    voxel_size : float, optional
        Voxel size used for computing volumetric progression, by default 0.1.
    enable_icp : bool, optional
        Whether to internally adjust 'after' to 'before' using ICP, by default False.

    Returns
    -------
    ProgressStats
        An object containing progress statistics: point counts, volume (m^3 and percent),
        and delta dimensions.

    Raises
    ------
    ValueError
        If either cloud has no points.

    Examples
    --------
    >>> stats = compute_progress("before.laz", "after.laz", "output.laz", tolerance=0.05)
    """
    before_laz_path = Path(before_laz_path)
    after_laz_path = Path(after_laz_path)
    output_laz_path = Path(output_laz_path)

    with laspy.open(before_laz_path) as f:
        total_before_points = f.header.point_count
        before_dims = np.array(f.header.maxs) - np.array(f.header.mins)
    with laspy.open(after_laz_path) as f:
        total_after_points = f.header.point_count

    if total_before_points == 0 or total_after_points == 0:
        raise ValueError("One of the point clouds is empty!")

    logger.info("Loading 'After' cloud...")
    after_xyz = load_xyz_from_laz(after_laz_path)
    transform_matrix = None

    if enable_icp:
        logger.info("Executing ICP for cloud alignment...")
        before_xyz_for_icp = load_xyz_from_laz(before_laz_path)
        transform_matrix, _, _ = get_icp_transformation(after_xyz, before_xyz_for_icp)
        after_xyz = apply_transform(after_xyz, transform_matrix)
        del before_xyz_for_icp

    after_dims = np.ptp(after_xyz, axis=0) if len(after_xyz) > 0 else np.zeros(3)
    delta_dims = after_dims - before_dims

    logger.info("Comparing Before -> After (Removed/Same)...")
    removed_pts_list, new_header = _process_removed(
        before_laz_path, after_xyz, output_laz_path, tolerance, use_gpu, chunk_size
    )
    del after_xyz

    logger.info("Loading 'Before' cloud...")
    before_xyz = load_xyz_from_laz(before_laz_path)
    vol_total = compute_volume(before_xyz, voxel_size)

    logger.info("Comparing After -> Before (New)...")
    new_pts_list = _process_new(
        after_laz_path,
        before_xyz,
        output_laz_path,
        new_header,
        tolerance,
        use_gpu,
        chunk_size,
        transform_matrix,
    )
    del before_xyz

    all_removed = (
        np.concatenate(removed_pts_list, axis=0)
        if removed_pts_list
        else np.empty((0, 3))
    )
    all_new = np.concatenate(new_pts_list, axis=0) if new_pts_list else np.empty((0, 3))
    all_changed = (
        np.concatenate((all_removed, all_new), axis=0)
        if len(all_removed) and len(all_new)
        else (
            all_removed
            if len(all_removed)
            else all_new if len(all_new) else np.zeros((0, 3))
        )
    )
    min_c = np.min(all_changed, axis=0) if len(all_changed) > 0 else np.zeros(3)
    max_c = np.max(all_changed, axis=0) if len(all_changed) > 0 else np.zeros(3)

    vol_removed = compute_volume(all_removed, voxel_size)
    vol_new = compute_volume(all_new, voxel_size)

    return ProgressStats(
        total_before_points=total_before_points,
        total_after_points=total_after_points,
        removed_points=len(all_removed),
        new_points=len(all_new),
        removed_volume_m3=vol_removed,
        removed_volume_percent=(
            (vol_removed / vol_total * 100) if vol_total > 0 else 0.0
        ),
        new_volume_m3=vol_new,
        new_volume_percent=(vol_new / vol_total * 100) if vol_total > 0 else 0.0,
        delta_width=float(delta_dims[0]),
        delta_length=float(delta_dims[1]),
        delta_height=float(delta_dims[2]),
        changes_width_range=(float(min_c[0]), float(max_c[0]), float(max_c[0]) - float(min_c[0])),
        changes_length_range=(float(min_c[1]), float(max_c[1]), float(max_c[1]) - float(min_c[1])),
        changes_height_range=(float(min_c[2]), float(max_c[2]), float(max_c[2]) - float(min_c[2])),
    )
