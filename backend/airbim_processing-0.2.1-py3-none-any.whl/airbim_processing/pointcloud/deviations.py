"""
Deviation analysis between real and ideal point clouds, with signed C2C metrics and
heatmap generation.
"""

import copy
from dataclasses import dataclass
import logging
import math
from pathlib import Path

import laspy
import numpy as np
import open3d as o3d

from .common import build_kdtree, load_xyz_from_laz, query_kdtree
from .icp import apply_transform, get_icp_transformation

logger = logging.getLogger(__name__)


@dataclass
class DeviationStats:
    """
    Computed statistics for point-to-point deviations.

    Attributes
    ----------
    total_points : int
        Total number of synchronized points processed between clouds.
    mean_signed_deviation : float
        Average signed distance; indicates general expansion or contraction.
    rmse : float
        Root Mean Square Error of the computed deviations.
    max_positive_deviation : float
        Maximum outer expansion limit (positive boundary deviation).
    max_negative_deviation : float
        Maximum inner contraction limit (negative boundary deviation).
    points_out_of_tolerance : int
        Count of points exceeding the specified tolerance threshold.
    """

    total_points: int
    mean_signed_deviation: float
    rmse: float
    max_positive_deviation: float
    max_negative_deviation: float
    points_out_of_tolerance: int


def _estimate_ideal_normals(
    ideal_xyz: np.ndarray, knn_radius: float, knn_max_nn: int
) -> np.ndarray:
    """
    Estimate and orient normal vectors for reference points.
    Horizontal normals are oriented upwards. Vertical/other normals are oriented
    outwards based on the point's relation to the geometric center.

    Parameters
    ----------
    ideal_xyz : np.ndarray
        Array of reference points of shape (N, 3).
    knn_radius : float
        Radius for the normal estimation search parameter.
    knn_max_nn : int
        Maximum number of neighbors for the normal estimation search parameter.

    Returns
    -------
    np.ndarray
        Array of normal vectors of shape (N, 3).
    """
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(ideal_xyz)
    pcd.estimate_normals(
        search_param=o3d.geometry.KDTreeSearchParamHybrid(
            radius=knn_radius, max_nn=knn_max_nn
        )
    )

    normals = np.asarray(pcd.normals)
    points = np.asarray(pcd.points)

    cos_45 = np.cos(np.radians(45.0))
    is_horizontal = np.abs(normals[:, 2]) >= cos_45

    mask_to_flip_horiz = is_horizontal & (normals[:, 2] < 0)
    normals[mask_to_flip_horiz] *= -1.0

    is_vertical = ~is_horizontal
    center_xy = (
        np.mean(points[is_vertical, :2], axis=0) if np.any(is_vertical) else np.zeros(2)
    )

    vec_from_center_xy = points[is_vertical, :2] - center_xy
    dot_prod = np.sum(normals[is_vertical, :2] * vec_from_center_xy, axis=1)

    mask_to_flip_vert = dot_prod < 0
    to_flip_indices = np.where(is_vertical)[0][mask_to_flip_vert]
    normals[to_flip_indices] *= -1.0

    return normals


def _process_deviation_chunks(
    real_laz_path: str | Path,
    output_laz_path: str | Path,
    kdtree,
    ideal_xyz: np.ndarray,
    ideal_normals: np.ndarray,
    on_gpu: bool,
    transform_matrix: np.ndarray | None,
    tolerance: float,
    metric: str,
    weights: np.ndarray,
    chunk_size: int,
) -> dict:
    """
    Iterate over chunks of the real scan, query nearest neighbors,
    compute signed C2C deviations, generate point colors, and write them sequentially.

    Parameters
    ----------
    real_laz_path : str | Path
        Path to the real/scanned LAZ file.
    output_laz_path : str | Path
        Path to write the resulting deviation-colored LAZ file.
    kdtree : cKDTree or cupyx.scipy.spatial.KDTree
        The built KD-Tree of the ideal point cloud.
    ideal_xyz : np.ndarray
        Array containing points of the ideal setup.
    ideal_normals : np.ndarray
        Estimated normals of the ideal point cloud.
    on_gpu : bool
        Indicates if the query is being run on the GPU.
    transform_matrix : np.ndarray | None
        4x4 transformation matrix from ICP alignment, or None.
    tolerance : float
        Acceptable threshold offset.
    metric : str
        Distance metric being used (e.g., "euclidean", "weighted", "chebyshev").
    weights : np.ndarray
        Weights applied to points during weighted KDTree queries.
    chunk_size : int
        Buffer chunk size for scanning data iterators.

    Returns
    -------
    dict
        Dictionary containing calculated data for deviation statistics.
    """
    real_laz_path = Path(real_laz_path)
    output_laz_path = Path(output_laz_path)
    p_metric = np.inf if metric == "chebyshev" else 2.0

    total_points = 0
    points_out_of_tolerance = 0
    sum_dev = 0.0
    sum_dev_sq = 0.0
    max_dev = -np.inf
    min_dev = np.inf

    with laspy.open(real_laz_path) as reader:
        header = copy.deepcopy(reader.header)
        header.point_format = laspy.PointFormat(7)
        header.add_extra_dim(
            laspy.ExtraBytesParams(name="deviation_m", type=np.float32)
        )
        header.add_extra_dim(laspy.ExtraBytesParams(name="is_deviation", type=np.uint8))

        with laspy.open(output_laz_path, mode="w", header=header) as writer:
            for pts in reader.chunk_iterator(chunk_size):
                real_xyz = np.column_stack((pts.x, pts.y, pts.z)).astype(
                    np.float64, copy=False
                )
                if transform_matrix is not None:
                    real_xyz = apply_transform(real_xyz, transform_matrix)

                current_count = len(real_xyz)
                if current_count == 0:
                    continue

                query_xyz = real_xyz * weights if metric == "weighted" else real_xyz

                _, indices = query_kdtree(kdtree, query_xyz, on_gpu, p=p_metric)

                ideal_nearest_xyz = ideal_xyz[indices]
                diff_vec = real_xyz - ideal_nearest_xyz
                distances = np.linalg.norm(diff_vec, axis=1)

                nearest_normals = ideal_normals[indices]
                signs = np.sign(np.sum(diff_vec * nearest_normals, axis=1))
                signs[signs == 0] = 1.0

                signed_dev = (distances * signs).astype(np.float32)

                red = np.zeros(current_count, dtype=np.uint16)
                green = np.zeros(current_count, dtype=np.uint16)
                blue = np.zeros(current_count, dtype=np.uint16)

                mask_pos_out = signed_dev > tolerance
                mask_neg_out = signed_dev < -tolerance
                mask_pos_in = (signed_dev >= 0) & (signed_dev <= tolerance)
                mask_neg_in = (signed_dev < 0) & (signed_dev >= -tolerance)

                red[mask_pos_out] = 65535
                blue[mask_neg_out] = 65535

                if np.any(mask_pos_in):
                    ratio_pos = signed_dev[mask_pos_in] / tolerance
                    red[mask_pos_in] = (ratio_pos * 65535).astype(np.uint16)
                    green[mask_pos_in] = 65535

                if np.any(mask_neg_in):
                    ratio_neg = np.abs(signed_dev[mask_neg_in]) / tolerance
                    blue[mask_neg_in] = (ratio_neg * 65535).astype(np.uint16)
                    green[mask_neg_in] = 65535

                out_pts = laspy.ScaleAwarePointRecord.zeros(
                    current_count, header=header
                )
                out_pts.copy_fields_from(pts)
                out_pts.x = pts.x
                out_pts.y = pts.y
                out_pts.z = pts.z

                out_pts.red = red
                out_pts.green = green
                out_pts.blue = blue
                out_pts.deviation_m = signed_dev
                out_pts.is_deviation = (mask_pos_out | mask_neg_out).astype(np.uint8)

                writer.write_points(out_pts)

                total_points += current_count
                points_out_of_tolerance += np.sum(mask_pos_out | mask_neg_out)
                sum_dev += np.sum(signed_dev)
                sum_dev_sq += np.sum(signed_dev**2)

                max_dev = max(max_dev, float(np.max(signed_dev)))
                min_dev = min(min_dev, float(np.min(signed_dev)))

    return {
        "total_points": total_points,
        "sum_dev": sum_dev,
        "sum_dev_sq": sum_dev_sq,
        "max_dev": max_dev,
        "min_dev": min_dev,
        "points_out_of_tolerance": points_out_of_tolerance,
    }


def compute_deviations(
    real_laz_path: str | Path,
    ideal_laz_path: str | Path,
    output_laz_path: str | Path,
    tolerance: float,
    metric: str = "euclidean",
    weights: tuple[float, float, float] = (1.0, 1.0, 1.0),
    use_gpu: bool = False,
    chunk_size: int = 1_000_000,
    knn_radius: float = 0.5,
    knn_max_nn: int = 30,
    enable_icp: bool = False,
) -> DeviationStats:
    """
    Calculate point-to-point (C2C) signed deviations between a real scan and an ideal reference.

    Normal vectors of the reference point cloud are used to determine if deviations
    are positive (outer expansion limit) or negative (inner contraction).

    Parameters
    ----------
    real_laz_path : str | Path
        Path to the real/scanned point cloud.
    ideal_laz_path : str | Path
        Path to the ideal/reference point cloud.
    output_laz_path : str | Path
        Path to save the resulting heatmap-annotated point cloud.
    tolerance : float
        Acceptable threshold offset.
    metric : {"euclidean", "chebyshev", "weighted"}, default="euclidean"
        Distance metric applied for finding nearest correspondence points.
    weights : tuple[float, float, float], default=(1.0, 1.0, 1.0)
        Weights applied to X, Y, Z if metric="weighted".
    use_gpu : bool, optional
        Whether to accelerate KdTree lookup on GPU, by default False.
    chunk_size : int, optional
        Buffer chunk size for scanning data iterators, by default 1_000_000.
    knn_radius : float, optional
        Radius parameter for normal estimation, by default 0.5.
    knn_max_nn : int, optional
        Max neighbors for normal estimation, by default 30.
    enable_icp : bool, optional
        Pre-calculate affine positioning of `real` to `ideal` using ICP, by default False.

    Returns
    -------
    DeviationStats
        An object containing deviations statistics: basic tolerances, total counts, RMSE, and metric ranges.

    Raises
    ------
    ValueError
        If the ideal point cloud is empty.

    Examples
    --------
    >>> stats = compute_deviations("real.laz", "ideal.laz", "output.laz", 0.05)
    """
    real_laz_path = Path(real_laz_path)
    ideal_laz_path = Path(ideal_laz_path)
    output_laz_path = Path(output_laz_path)

    logger.info("Loading ideal cloud...")
    ideal_xyz = load_xyz_from_laz(ideal_laz_path)
    if len(ideal_xyz) == 0:
        raise ValueError("Ideal point cloud is empty!")

    transform_matrix = None
    if enable_icp:
        logger.info("Executing ICP for cloud alignment...")
        real_xyz_for_icp = load_xyz_from_laz(real_laz_path)
        transform_matrix, _, _ = get_icp_transformation(real_xyz_for_icp, ideal_xyz)
        del real_xyz_for_icp

    logger.info("Estimating ideal normals...")
    ideal_normals = _estimate_ideal_normals(ideal_xyz, knn_radius, knn_max_nn)

    logger.info("Initializing KDTree...")
    w_array = np.array(weights, dtype=np.float64)
    tree_ideal_xyz = ideal_xyz * w_array if metric == "weighted" else ideal_xyz

    kdtree, on_gpu, gpu_pts = build_kdtree(tree_ideal_xyz, use_gpu)

    if metric == "weighted":
        del tree_ideal_xyz

    logger.info("Processing scan chunks (Metric: %s)...", metric)
    result_stats = _process_deviation_chunks(
        real_laz_path=real_laz_path,
        output_laz_path=output_laz_path,
        kdtree=kdtree,
        ideal_xyz=ideal_xyz,
        ideal_normals=ideal_normals,
        on_gpu=on_gpu,
        transform_matrix=transform_matrix,
        tolerance=tolerance,
        metric=metric,
        weights=w_array,
        chunk_size=chunk_size,
    )

    if gpu_pts is not None:
        del gpu_pts
    del kdtree

    logger.info("Analysis complete.")

    total_pts = result_stats["total_points"]

    return DeviationStats(
        total_points=total_pts,
        mean_signed_deviation=(
            float(result_stats["sum_dev"] / total_pts) if total_pts > 0 else 0.0
        ),
        rmse=(
            math.sqrt(result_stats["sum_dev_sq"] / total_pts) if total_pts > 0 else 0.0
        ),
        max_positive_deviation=result_stats["max_dev"],
        max_negative_deviation=result_stats["min_dev"],
        points_out_of_tolerance=int(result_stats["points_out_of_tolerance"]),
    )
